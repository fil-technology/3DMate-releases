#!/usr/bin/env python3
"""3D Mate LATO.2 runner. Emits the same JSONL protocol as the other engines
(job_started / stage_started / progress / artifact / job_finished / error) so the
app consumes it identically.

LATO.2 generates ARTIST TOPOLOGY with a controllable vertex budget. A photo goes
in, a clean mesh comes out, in two phases run as SEPARATE child processes so the
two model stacks never sit in unified memory at once (this is what makes it fit on
a big-memory Mac at all):

  phase "ss"   : TRELLIS.2's sparse-structure stage turns the photo into a 64^3
                 occupancy scaffold (coords.npy) + a conditioning image (cond.png),
                 then exits so all SS / DINOv3 / Metal memory is released.
  phase "lato" : loads ONLY LATO.2 and runs V-Flow -> V-VAE (place `--vert-num`
                 vertices) then T-Flow -> T-VAE (decode their connectivity), and
                 exports the mesh as output.glb + output.stl.

Everything runs on Apple Silicon via MPS through a pure-torch sparse backend
(SPARSE_BACKEND=pytorch, ATTN_BACKEND=sdpa): no CUDA, no spconv, no flash_attn.
Geometry only (no texture stage), so this NEVER emits a `baking_textures` stage.

Code layout. The LATO.2 package (its `modules`/`models`/`utils`, with the
Apple-Silicon port overlay) and the TRELLIS.2 sparse-structure fork (`trellis2/`)
are vendored INSIDE the engine pack, next to this interpreter, at <pack>/lato_src
and <pack>/trellis2_fork. On a dev machine THREEDMATE_LATO2_REPO and
THREEDMATE_LATO2_SS_REPO point at the working clones instead. Weights load offline
from the plain Models/LATO2 bundle passed as --model-folder: ckpt/ (LATO weights +
dinov2), ss/ (the TRELLIS.2 SS pipeline.json + ckpts), hfcache/ (DINOv3)."""
import argparse
import json
import math
import os
import subprocess
import sys
import tempfile
import threading
import time
import traceback

# Unsupported MPS ops fall back to CPU instead of crashing the run. The two-phase
# design keeps peak memory bounded; the sparse backend and SDPA attention keep it
# off any CUDA-only path.
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
os.environ.setdefault("SPARSE_BACKEND", "pytorch")
os.environ.setdefault("ATTN_BACKEND", "sdpa")

_emit_lock = threading.Lock()


def emit(obj):
    with _emit_lock:
        print(json.dumps(obj), flush=True)


# --------------------------------------------------------------------------- #
# Path resolution: prefer the dev clones (env), else the vendored pack trees.
# --------------------------------------------------------------------------- #
def _first_existing(*paths):
    for p in paths:
        if p and os.path.isdir(p):
            return p
    return ""


def lato_root():
    return _first_existing(os.environ.get("THREEDMATE_LATO2_REPO", ""),
                           os.path.join(sys.prefix, "lato_src"))


def trellis_fork():
    return _first_existing(os.environ.get("THREEDMATE_LATO2_SS_REPO", ""),
                           os.path.join(sys.prefix, "trellis2_fork"))


# --------------------------------------------------------------------------- #
# Phase 1: TRELLIS.2 sparse-structure scaffold from a photo (child process).
# Faithful to the proven port (scripts/ss_scaffold.py): load ONLY the SS models,
# preprocess (rembg cutout), sample the 64^3 structure, write coords.npy+cond.png.
# --------------------------------------------------------------------------- #
def run_phase_ss(image, out_dir, ss_models, resolution=64):
    fork = trellis_fork()
    if fork and fork not in sys.path:
        sys.path.insert(0, fork)
    import numpy as np
    import torch
    from PIL import Image
    from trellis2.pipelines.trellis2_image_to_3d import Trellis2ImageTo3DPipeline

    class SSPipeline(Trellis2ImageTo3DPipeline):
        # Load ONLY the sparse-structure models (skip the multi-GB SLat/tex).
        model_names_to_load = ["sparse_structure_flow_model", "sparse_structure_decoder"]

    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    print("[ss] loading TRELLIS.2 sparse-structure pipeline ...", flush=True)
    ss = SSPipeline.from_pretrained(ss_models)
    ss.to(device)
    img = Image.open(image)
    img = ss.preprocess_image(img)  # rembg cutout -> RGBA
    with torch.no_grad():
        cond = ss.get_cond([img], 512)
        coords = ss.sample_sparse_structure(cond, resolution).cpu().numpy()  # (N,4)

    rgba = np.array(img.convert("RGBA")).astype(np.float32)
    al = rgba[..., 3:4] / 255.0
    cond_img = (rgba[..., :3] * al + 255.0 * (1.0 - al)).astype(np.uint8)
    os.makedirs(out_dir, exist_ok=True)
    np.save(os.path.join(out_dir, "coords.npy"), coords)
    Image.fromarray(cond_img).save(os.path.join(out_dir, "cond.png"))
    print(f"[ss] wrote {coords.shape[0]} active voxels @ res {resolution} + cond.png", flush=True)
    return 0


# --------------------------------------------------------------------------- #
# Phase 2: LATO.2 mesh from the scaffold (child process). Faithful to the proven
# port (scripts/lato_generate.py): V-Flow -> V-VAE, then T-Flow -> T-VAE with
# bf16 autocast (matching the stock CUDA path; V-Flow stays fp32). Exports the
# mesh straight through trimesh as output.glb + output.stl.
# --------------------------------------------------------------------------- #
def run_phase_lato(scaffold_dir, ckpt_dir, out_glb, out_stl, vert_num, seed):
    root = lato_root()
    if root and root not in sys.path:
        sys.path.insert(0, root)
    from types import SimpleNamespace
    import numpy as np
    import torch
    from PIL import Image

    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    torch.manual_seed(seed)
    np.random.seed(seed)

    coords = torch.from_numpy(np.load(os.path.join(scaffold_dir, "coords.npy")))
    cond_img = np.array(Image.open(os.path.join(scaffold_dir, "cond.png")).convert("RGB"))
    print(f"[lato] scaffold: {coords.shape[0]} voxels; cond image {cond_img.shape}", flush=True)

    from modules.sparse import SparseTensor
    from models import (
        DinoV2Encoder, OffsetHead, TopoFlowEulerSampler, TopologySiTFlow,
        TopologyVAE, VertexSLatFlowModel, VertFlowEulerCfgSampler, VertexVAE,
        VoxelFieldConditioner,
    )
    from utils.load import load_latov2_model
    from utils.inference import (
        build_voxel_fields, compute_density, decode_vertices, edges_to_faces, pad_verts,
    )

    C = ckpt_dir
    vflow, vflow_cfg = load_latov2_model(VertexSLatFlowModel, f"{C}/vflow.pt", device)
    vvae, vvae_cfg = load_latov2_model(VertexVAE, f"{C}/vvae.pt", device)
    offset_head, _ = load_latov2_model(OffsetHead, f"{C}/offset_head.pt", device)
    tflow, tflow_cfg = load_latov2_model(TopologySiTFlow, f"{C}/tflow.pt", device)
    tvae, _ = load_latov2_model(TopologyVAE, f"{C}/tvae.pt", device)
    voxel_encoder, venc_cfg = load_latov2_model(VoxelFieldConditioner, f"{C}/voxel_encoder.pt", device)

    res = vvae_cfg["resolution"]
    latent_dim = vflow_cfg["latent_dim"]
    density_max = vflow_cfg["max_vertex_num"]
    z_dim = int(tflow_cfg["args"]["z_dim"])
    max_vertices = int(tflow_cfg["args"]["max_vertices"])
    latent_scale = float(tflow_cfg["latent_scale"])
    voxel_res = int(venc_cfg["resolution"])

    dino = DinoV2Encoder(model_name=vflow_cfg["dino_version"],
                         hub_dir=os.path.join(C, "dinov2"),
                         img_res=vflow_cfg["image_resolution"]).to(device).eval()
    vertex_sampler = VertFlowEulerCfgSampler()
    topo_sampler = TopoFlowEulerSampler()

    args = SimpleNamespace(vert_num=vert_num, use_gt_vert_count=False, scaler=1.0,
                           min_verts=200.0, max_verts=5000.0)
    batch = {"name": ["img"], "image": [cond_img], "quantized_vertices": [torch.zeros((1, 3))]}
    density = compute_density(batch, args, density_max, device)

    with torch.no_grad():
        cond = dino(np.stack(batch["image"])).float()
        neg_cond = torch.zeros_like(cond)

    # ---- stage 1: V-Flow on the 64^3 scaffold -> V-VAE vertex decode (fp32) ----
    min_active = coords.to(device)
    with torch.no_grad(), torch.autocast("mps", enabled=False):
        noise = SparseTensor(coords=min_active.int(),
                             feats=torch.randn(min_active.shape[0], latent_dim, device=device))
        z_pred = vertex_sampler.sample(model=vflow, noise=noise, cond=cond, neg_cond=neg_cond,
                                       steps=24, cfg_strength=3.0, rescale_t=1.0, density=density)
        pred_coords, pred_offsets = decode_vertices(vvae, offset_head, z_pred, 0.5)

    pred_sel = pred_coords[:, 0] == 0
    vert_int = pred_coords[pred_sel, 1:].long()
    vert_off = pred_offsets[pred_sel]
    num_pred = int(vert_int.shape[0])
    print(f"[lato] V-Flow produced {num_pred} vertices", flush=True)
    if num_pred < 3 or num_pred > max_vertices:
        print(f"[lato] vertex count {num_pred} out of [3,{max_vertices}]; no topology.", flush=True)
        return 2

    # ---- stage 2: T-Flow on the vertices -> T-VAE edge decode (bf16 autocast) ----
    with torch.no_grad(), torch.autocast(device.type, dtype=torch.bfloat16):
        verts, mask, lengths = pad_verts([vert_int], device)
        field = build_voxel_fields([min_active[min_active[:, 0] == 0, 1:].long()], voxel_res, device)
        cond_vox = voxel_encoder(field)
        z0 = torch.randn(verts.shape[0], verts.shape[1], z_dim, device=device)
        z_flow = topo_sampler.sample(model=tflow, noise=z0, verts=verts, mask=mask,
                                     cond=cond_vox, steps=50)
        z = z_flow.float() / latent_scale
        edges_list = tvae.decode(z, verts=verts, verts_mask=mask, chunk_size=20000, threshold=0.0)

    faces = edges_to_faces(edges_list[0], lengths[0], True)
    print(f"[lato] T-Flow produced {faces.shape[0]} faces", flush=True)
    if faces.shape[0] == 0:
        print("[lato] no faces decoded.", flush=True)
        return 2

    import trimesh
    resf = float(res)
    verts_world = (vert_int.numpy().astype(np.float64) / resf - 0.5
                   + vert_off.numpy().astype(np.float64) / (resf * 2.0))
    mesh = trimesh.Trimesh(vertices=verts_world, faces=faces)
    # Keep outward-facing normals (positive signed volume; see the inside-out
    # casebook). Harmless when already correct.
    try:
        if mesh.volume < 0:
            mesh.invert()
    except Exception:  # noqa: BLE001
        pass
    mesh.export(out_glb)
    stl_ok = False
    try:
        mesh.export(out_stl)
        stl_ok = True
    except Exception as exc:  # noqa: BLE001
        print(f"[lato] STL export failed: {exc}", flush=True)
    print("LATO_RESULT " + json.dumps({"verts": num_pred, "faces": int(faces.shape[0]),
                                       "glb": out_glb, "stl": out_stl if stl_ok else ""}), flush=True)
    return 0


# --------------------------------------------------------------------------- #
# Child entry: run one phase in this process, then exit (frees all its memory).
# --------------------------------------------------------------------------- #
def child_main(a):
    if a.phase == "ss":
        return run_phase_ss(a.image, a.scaffold_dir, a.ss_models)
    if a.phase == "lato":
        return run_phase_lato(a.scaffold_dir, a.ckpt_dir, a.glb, a.stl, a.vert_num, a.seed)
    return 1


# --------------------------------------------------------------------------- #
# Parent orchestrator: spawn each phase as a child, translate its stdout to the
# JSONL protocol, and drive the progress bar with a heartbeat per phase.
# --------------------------------------------------------------------------- #
def _run_child(phase_args, stage, base_percent, span_percent, tau, log_prefix):
    """Spawn `sys.executable lato2_generate.py --phase ...`, forwarding the child's
    lines as `log` events and advancing `stage` from base_percent by span_percent
    (asymptotic). Returns (exit_code, [captured lines])."""
    env = dict(os.environ)
    # Make the vendored/dev trees importable in the child too.
    root, fork = lato_root(), trellis_fork()
    extra_path = os.pathsep.join([p for p in (root, fork) if p])
    if extra_path:
        env["PYTHONPATH"] = extra_path + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    cmd = [sys.executable, os.path.abspath(__file__)] + phase_args
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            env=env, text=True, bufsize=1)

    stop = threading.Event()

    def _heartbeat(t0):
        while not stop.wait(5.0):
            elapsed = time.time() - t0
            frac = 1.0 - math.exp(-elapsed / tau)
            emit({"type": "progress", "stage": stage,
                  "percent": int(round(base_percent + span_percent * frac)),
                  "message": None})

    hb = threading.Thread(target=_heartbeat, args=(time.time(),), daemon=True)
    hb.start()
    lines = []
    for line in proc.stdout:
        line = line.rstrip("\n")
        if not line:
            continue
        lines.append(line)
        emit({"type": "log", "level": "info", "message": f"{log_prefix}{line}"})
    proc.wait()
    stop.set()
    hb.join(timeout=2)
    return proc.returncode, lines


def parent_main(a):
    start = time.time()
    emit({"type": "job_started", "job_id": a.job_id})
    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})
    if not os.path.exists(a.image):
        emit({"type": "error", "message": "Input image not found.", "recoverable": False})
        return 1

    mf = a.model_folder
    ss_models = os.path.join(mf, "ss") if mf else ""
    ckpt_dir = os.path.join(mf, "ckpt") if mf else ""
    hf_home = os.path.join(mf, "hfcache") if mf else ""
    if hf_home and os.path.isdir(hf_home):
        os.environ["HF_HOME"] = hf_home
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

    if not (ss_models and os.path.isdir(ss_models)) or not (ckpt_dir and os.path.isdir(ckpt_dir)):
        emit({"type": "error", "recoverable": False,
              "message": "The LATO.2 weights are not installed. Install LATO.2 in Settings, Engines."})
        return 1

    try:
        vert_num = max(200, min(5000, int(a.vert_num)))
    except (TypeError, ValueError):
        vert_num = 4000
    try:
        seed = int(a.seed)
    except (TypeError, ValueError):
        seed = 42

    job_folder = os.path.dirname(os.path.abspath(a.image))
    out_glb = os.path.join(job_folder, "output.glb")
    out_stl = os.path.join(job_folder, "output.stl")

    with tempfile.TemporaryDirectory(prefix="lato2-scaffold-") as scaffold_dir:
        # ---- phase 1: scaffold (its own process; SS+DINOv3 memory freed on exit) --
        emit({"type": "stage_started", "stage": "generating_structure", "message": "Reading shape"})
        emit({"type": "progress", "stage": "generating_structure", "percent": 5, "message": "Reading shape…"})
        rc, _ = _run_child(["--phase", "ss", "--image", a.image,
                            "--scaffold-dir", scaffold_dir, "--ss-models", ss_models],
                           stage="generating_structure", base_percent=5, span_percent=45,
                           tau=90.0, log_prefix="[ss] ")
        if rc != 0 or not os.path.exists(os.path.join(scaffold_dir, "coords.npy")):
            emit({"type": "error", "recoverable": True,
                  "message": "Could not read the shape from the photo. This often means the machine ran "
                             "low on memory; close other apps (Google Drive especially) and try again."})
            return 1

        # ---- phase 2: LATO mesh (its own process; loads only LATO) ----------------
        emit({"type": "stage_started", "stage": "generating_mesh", "message": "Building mesh"})
        emit({"type": "progress", "stage": "generating_mesh", "percent": 55, "message": "Building mesh…"})
        rc, lines = _run_child(["--phase", "lato", "--scaffold-dir", scaffold_dir,
                               "--ckpt-dir", ckpt_dir, "--glb", out_glb, "--stl", out_stl,
                               "--vert-num", str(vert_num), "--seed", str(seed)],
                              stage="generating_mesh", base_percent=55, span_percent=40,
                              tau=120.0, log_prefix="[lato] ")

    result = None
    for line in lines:
        if line.startswith("LATO_RESULT "):
            try:
                result = json.loads(line[len("LATO_RESULT "):])
            except json.JSONDecodeError:
                result = None
    if rc != 0 or result is None or not os.path.exists(out_glb):
        low_memory = any(m in "\n".join(lines) for m in
                         ("Cannot allocate", "out of memory", "MemoryError", "Interrupted system call"))
        if low_memory:
            emit({"type": "error", "recoverable": True,
                  "message": "Ran low on memory while building the mesh. LATO.2 needs a big-memory Mac; "
                             "close other apps and try again, or lower the vertex budget."})
        else:
            emit({"type": "error", "recoverable": False,
                  "message": "LATO.2 did not produce a mesh. See the log for details."})
        return 1

    emit({"type": "artifact", "kind": "glb", "path": out_glb})
    if result.get("stl") and os.path.exists(out_stl):
        emit({"type": "artifact", "kind": "stl", "path": out_stl})
    emit({"type": "log", "level": "info",
          "message": f"[lato] {result.get('verts', 0)} vertices, {result.get('faces', 0)} faces"})
    emit({"type": "stage_started", "stage": "exporting_glb", "message": "Finishing"})
    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})
    return 0


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--image", default="")
    p.add_argument("--output", default="")      # accepted for parity; job folder is the image's dir
    p.add_argument("--job-id", dest="job_id", default="lato2")
    p.add_argument("--model-folder", dest="model_folder", default="")
    p.add_argument("--vert-num", dest="vert_num", default="4000")
    p.add_argument("--seed", default="42")
    # Hidden per-phase child entry points (the parent re-invokes this file).
    p.add_argument("--phase", choices=["ss", "lato"], default=None)
    p.add_argument("--scaffold-dir", dest="scaffold_dir", default="")
    p.add_argument("--ss-models", dest="ss_models", default="")
    p.add_argument("--ckpt-dir", dest="ckpt_dir", default="")
    p.add_argument("--glb", default="")
    p.add_argument("--stl", default="")
    a, _ = p.parse_known_args()
    a.vert_num = a.vert_num if a.phase != "lato" else int(a.vert_num)
    a.seed = a.seed if a.phase != "lato" else int(a.seed)

    if a.phase:
        # Child: no JSONL, just print/return; the parent translates our stdout.
        try:
            return child_main(a)
        except Exception:  # noqa: BLE001
            traceback.print_exc()
            return 1
    return parent_main(a)


if __name__ == "__main__":
    sys.exit(main())
