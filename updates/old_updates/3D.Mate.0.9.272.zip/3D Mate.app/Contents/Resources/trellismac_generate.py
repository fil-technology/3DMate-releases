#!/usr/bin/env python3
"""3D Mate backend wrapper. JSONL progress protocol.

The Swift app (TrellisGenerationBackend) launches this script and parses one
JSON object per stdout line:

    {"type":"job_started","job_id":"..."}
    {"type":"stage_started","stage":"loading_model","message":"Loading model"}
    {"type":"progress","stage":"generating_structure","percent":35,"message":"..."}
    {"type":"artifact","kind":"glb","path":"/path/output.glb"}
    {"type":"job_finished","duration_seconds":320}
    {"type":"job_cancelled"}
    {"type":"error","message":"...","recoverable":true}

Modes:
  --mock   simulate the pipeline (no model needed). Used by the in-app mock
           backend tests and CI.
  (real)   dispatch to the trellis-mac backend (PyTorch MPS port of TRELLIS.2)
           set up by Scripts/setup_backend_phase1b.sh inside the external SSD
           workspace, translating its console output into JSONL stages.

All caches stay on the external SSD. The app exports HF_HOME/TMPDIR/etc.
before launching this script.
"""
import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid

STAGES = [
    ("validating_input", 0.3, "Validating input"),
    ("preparing_image", 0.4, "Preparing image"),
    ("loading_model", 1.0, "Loading model"),
    ("generating_structure", 2.0, "Generating structure"),
    ("generating_mesh", 1.5, "Generating mesh"),
    ("baking_textures", 1.2, "Baking textures"),
    ("exporting_glb", 0.4, "Exporting GLB"),
    ("exporting_usdz", 0.4, "Exporting USDZ"),
]

SPEED = {"fast": 0.5, "balanced": 1.0, "quality": 1.8}

# preset -> (pipeline type, texture size, bake face budget).
# 512² textures are far too sparse for ~200k-face meshes (≈1 texel/triangle,
# reads as speckle) — upstream's own default is 1024 even for the 512 pipeline.
# The face budget bounds xatlas UV-unwrap time, the dominant cost on M1
# (the Metal baker needs float atomics = M2+).
REAL_PRESETS = {
    "fast": ("512", 1024, 100_000),
    "balanced": ("512", 2048, 200_000),
    "quality": ("1024", 2048, 300_000),
}


# Set once the engine subprocess exists, so a dead stdout (the app quit,
# crashed, or was killed mid-run) takes the engine down with us instead of
# leaving it orphaned on the GPU until Metal errors turn into a crash dialog.
RUNNER_PROC = None


def emit(obj):
    try:
        print(json.dumps(obj), flush=True)
    except BrokenPipeError:
        if RUNNER_PROC is not None and RUNNER_PROC.poll() is None:
            RUNNER_PROC.terminate()
            try:
                RUNNER_PROC.wait(timeout=10)
            except Exception:
                RUNNER_PROC.kill()
        os._exit(141)


# --------------------------------------------------------------------------
# Mock mode
# --------------------------------------------------------------------------

def run_mock(args, job_dir, job_id):
    start = time.time()
    scale = SPEED[args.preset]
    total = sum(d for _, d, _ in STAGES) * scale
    done = 0.0

    shutil.copy(args.image, os.path.join(job_dir, "input.png"))
    shutil.copy(args.image, os.path.join(job_dir, "prepared.png"))
    with open(os.path.join(job_dir, "config.json"), "w") as f:
        json.dump({"job_id": job_id, "preset": args.preset, "seed": args.seed,
                   "model_folder": args.model_folder, "mock": True}, f, indent=2)

    for stage, duration, label in STAGES:
        duration *= scale
        emit({"type": "stage_started", "stage": stage, "message": label})
        steps = max(1, int(duration / 0.25))
        for i in range(steps):
            time.sleep(duration / steps)
            percent = int(100 * (done + duration * (i + 1) / steps) / total)
            emit({"type": "progress", "stage": stage, "percent": min(percent, 99),
                  "stage_percent": int(100 * (i + 1) / steps), "message": label})
        done += duration

        if stage == "exporting_glb":
            path = os.path.join(job_dir, "output.glb")
            with open(path, "wb") as f:
                f.write(b"3DMate mock placeholder (not a real GLB)")
            emit({"type": "artifact", "kind": "glb", "path": path})
        elif stage == "exporting_usdz":
            path = os.path.join(job_dir, "output.usdz")
            with open(path, "wb") as f:
                f.write(b"3DMate mock placeholder (not a real USDZ)")
            emit({"type": "artifact", "kind": "usdz", "path": path})

    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})


# --------------------------------------------------------------------------
# Real mode — trellis-mac (TRELLIS.2 on PyTorch MPS)
# --------------------------------------------------------------------------

# (regex, stage, percent-at-entry) — first match wins, order matters.
STAGE_PATTERNS = [
    (re.compile(r"loading pipeline|from_pretrained|loading model|loading weights", re.I), "loading_model", 8),
    (re.compile(r"preprocess|background|rembg|segment", re.I), "preparing_image", 16),
    # "sampling …" prefixes matter: the model loader logs names like
    # "shape_slat_flow_model_512", and a bare "slat" match advanced the
    # stage to Mesh during LOADING — pinning the bar at 55% through the
    # whole structure-sampling phase (monotonic guard blocks going back).
    (re.compile(r"sampling sparse structure|sparse structure sampl|stage 1\b", re.I), "generating_structure", 25),
    (re.compile(r"sampling (shape|texture) slat|structured latent|stage 2\b|decoding|mesh extract|flexicubes|marching", re.I), "generating_mesh", 55),
    (re.compile(r"baking|uv unwrap|xatlas|texture|simplify", re.I), "baking_textures", 75),
    (re.compile(r"saved: .*\.glb|exporting glb", re.I), "exporting_glb", 95),
]

# Fine-grained progress: the engines log tqdm iteration lines
# ("Sampling shape SLat:  42%|████     | 5/12 [...]") — interpolate within
# the stage's percent span instead of sitting still until the next stage.
# Overall-percent band of each app stage; stage_percent is the position
# inside the band, so the UI checklist can show per-phase progress that
# stays monotonic even when one stage runs several sampling passes.
STAGE_BANDS = {
    "validating_input": (0, 8),
    "loading_model": (8, 16),
    "preparing_image": (16, 25),
    "generating_structure": (25, 55),
    "generating_mesh": (55, 75),
    "baking_textures": (75, 95),
    "exporting_glb": (95, 98),
    "exporting_usdz": (98, 100),
}


def stage_percent_for(stage, overall):
    lo, hi = STAGE_BANDS.get(stage, (0, 100))
    if hi <= lo:
        return 100
    return max(0, min(100, int(round((overall - lo) * 100.0 / (hi - lo)))))


TQDM_RE = re.compile(r"(sampling [a-z ]+?):\s+\d+%\|.*?\|\s*(\d+)/(\d+)", re.I)
SUBSTAGE_SPANS = {
    "sampling sparse structure": (25, 55),
    "sampling shape slat": (55, 65),
    "sampling texture slat": (65, 73),
}
SUBSTEP_MARKS = [
    (re.compile(r"mesh extraction done", re.I), 74),
    (re.compile(r"simplifying mesh", re.I), 76),
    (re.compile(r"uv unwrapping", re.I), 80),
    (re.compile(r"baking pbr textures", re.I), 84),
    (re.compile(r"finalizing mesh", re.I), 92),
]

# Live step previews from the engine adapters — handled before SAVED_RE,
# which would otherwise treat them as the job's preview artifact.
PREVIEW_STEP_RE = re.compile(r"\[PREVIEW\] saved:\s*(.+?\.png)\s*$")
PREVIEW_POINTS_RE = re.compile(r"\[PREVIEW\] points:\s*(.+?\.bin)\s*$")

# Paths may contain spaces (e.g. "/Volumes/Sviat SSD/…") — match to end of line.
SAVED_RE = re.compile(r"Saved:\s*(.+?\.(glb|obj|png))\s*$", re.I)


def find_workspace(args):
    ws = os.environ.get("THREEDMATE_WORKSPACE")
    if ws and os.path.isdir(ws):
        return ws
    # output folder is <workspace>/Jobs — derive from there
    parent = os.path.dirname(os.path.abspath(args.output.rstrip("/")))
    return parent if os.path.isdir(parent) else None


def find_engine_pack():
    """The newest installed engine pack's interpreter, or None.

    Since 0.9.207 the app installs (and migrates) gigabyte-class packs onto the
    external workspace drive at <workspace>/Engines/engine/<version>/, keeping
    them off the startup disk; the old location is
    ~/Library/Application Support/3DMate/engine/<version>/. Swift's
    EngineInstaller.enginesDirectory prefers the workspace copy and falls back to
    the legacy one. This MUST search the same places in the same order, or the
    MLX engine (which resolves its pack here) reports "trellis2-apple backend not
    installed" while the app's health check, using the workspace-aware Swift
    resolver, says the model is ready.

    Fast path: the app already launches this wrapper with the pack's own
    interpreter, so sys.executable usually IS the pack python.
    """
    exe = os.path.realpath(sys.executable)
    if os.path.basename(exe) == "python3.11" and \
       os.path.basename(os.path.dirname(exe)) == "bin":
        return exe

    bases = []
    workspace = os.environ.get("THREEDMATE_WORKSPACE")
    if workspace:
        bases.append(os.path.join(workspace, "Engines", "engine"))
    bases.append(os.path.expanduser("~/Library/Application Support/3DMate/engine"))

    for base in bases:
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base), reverse=True):
            py = os.path.join(base, name, "bin", "python3.11")
            if os.path.isfile(py):
                return py
    return None


def run_real(args, job_dir, job_id):
    start = time.time()
    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})

    workspace = find_workspace(args)
    repo_name = "trellis2-apple" if args.engine == "mlx" else "trellis-mac"

    # Prefer a customer-installed engine pack: a self-contained relocatable
    # Python with the fork (trellis2/mlx_backend/o_voxel) baked into
    # site-packages, so no fork checkout is needed. Runs with cwd = the job
    # folder. Falls back to the dev repo + .venv below so the developer
    # workflow (and this machine) is unchanged.
    pack_python = find_engine_pack() if args.engine == "mlx" else None
    if pack_python:
        venv_python = pack_python
        engine_cwd = job_dir
        emit({"type": "log", "message": "Using installed engine pack"})
    else:
        # Source builds live inside a sparse APFS image on the SSD (exFAT can't
        # host them), mounted at /Volumes/3DMate-Dev — attach it on demand.
        candidates = [
            f"/Volumes/3DMate-Dev/BackendCandidates/{repo_name}",
            os.path.join(workspace or "", "Repos", "BackendCandidates", repo_name),
        ]
        image = os.path.join(workspace or "", "DevRepos.sparseimage")
        if not any(os.path.isdir(c) for c in candidates) and os.path.isfile(image):
            emit({"type": "log", "message": "Attaching workspace dev image…"})
            subprocess.run(["hdiutil", "attach", "-nobrowse", image],
                           capture_output=True, timeout=60)

        repo = next((c for c in candidates if os.path.isdir(c)), candidates[0])
        venv_python = os.path.join(repo, ".venv", "bin", "python3")
        engine_cwd = repo
        if not os.path.isdir(repo) or not os.path.isfile(venv_python):
            emit({"type": "error", "recoverable": False,
                  "message": f"{repo_name} backend not installed. Install the engine, or run the dev setup."})
            sys.exit(4)

    if os.path.abspath(os.path.dirname(args.image)) != os.path.abspath(job_dir):
        shutil.copy(args.image, os.path.join(job_dir, "prepared.png"))
    with open(os.path.join(job_dir, "config.json"), "w") as f:
        json.dump({"job_id": job_id, "preset": args.preset, "seed": args.seed,
                   "model_folder": args.model_folder, "backend": repo_name}, f, indent=2)

    pipeline_type, texture_size, bake_faces = REAL_PRESETS[args.preset]
    # The "Geometry" model option can raise geometry to the 1024 cascade on any
    # preset (roughly 4x more raw faces for crisper small forms, at roughly
    # triple the sampling time). "standard" keeps the preset's native geometry,
    # so Quality (already 1024) is never downgraded; "high" forces the cascade.
    # "1024" is exactly the Quality preset's value, so it flows through the same
    # mlx map ({"512","1024"}) and MPS path that Quality already uses.
    if args.geometry == "high":
        pipeline_type = "1024"
    output_base = os.path.join(job_dir, "output")

    env = dict(os.environ)
    env.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
    env["PYTHONUNBUFFERED"] = "1"  # live progress lines, not 8 KB bursts
    env["TRELLIS_BAKE_TARGET_FACES"] = str(bake_faces)
    env["TRELLIS_PREVIEW_DIR"] = job_dir  # live step previews land here
    if args.engine == "mlx" and args.preset == "fast":
        # Fast is a draft mode: fewer CFG passes AND fewer sampler steps.
        # Sampling dominates runtime and scales with image complexity —
        # trimming steps is the only lever that meaningfully cuts it.
        env["TRELLIS_MLX_NARROW_GUIDANCE"] = "1"
        env.setdefault("TRELLIS_MLX_STEPS", "8")
    # Use the pre-downloaded weights in the workspace when they look complete.
    if args.model_folder and os.path.isfile(os.path.join(args.model_folder, "pipeline.json")):
        env["TRELLIS2_MODEL"] = args.model_folder

    if args.engine == "mlx":
        # MLX runner ships next to this wrapper in the app bundle.
        runner = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mlx_runner.py")
        mlx_pipeline = {"512": "512", "1024": "1024_cascade"}[pipeline_type]
        cmd = [venv_python, runner, args.image, *args.view,
               "--seed", str(args.seed),
               "--output", output_base,
               "--pipeline-type", mlx_pipeline,
               "--texture-size", str(texture_size)]
        if args.geometry_only:
            cmd.append("--geometry-only")
        if args.view:
            emit({"type": "log", "message": f"Multi-view: {len(args.view) + 1} views condition this generation"})
    else:
        cmd = [venv_python, "generate.py", args.image,
               "--seed", str(args.seed),
               "--output", output_base,
               "--pipeline-type", pipeline_type,
               "--texture-size", str(texture_size)]
    emit({"type": "log", "message": "exec: " + " ".join(cmd)})

    proc = subprocess.Popen(cmd, cwd=engine_cwd, env=env, text=True, bufsize=1,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    global RUNNER_PROC
    RUNNER_PROC = proc
    # Deliver a dead stdout as BrokenPipeError (handled in emit) instead of
    # an instant SIGPIPE kill that would skip child cleanup entirely.
    signal.signal(signal.SIGPIPE, signal.SIG_IGN)

    def forward_terminate(signum, frame):
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
        emit({"type": "job_cancelled"})
        sys.exit(130)

    signal.signal(signal.SIGTERM, forward_terminate)
    signal.signal(signal.SIGINT, forward_terminate)

    stage_order = [s for s, _, _ in STAGES]
    current_stage = "loading_model"
    percent = 5
    artifacts = []

    # The first ~10 s are interpreter/framework imports with no output —
    # show a sliver of progress so the bar isn't dead at 0%.
    percent = max(percent, 3)
    emit({"type": "progress", "stage": current_stage, "percent": percent, "message": "Starting engine…"})

    last_error = ""
    for line in proc.stdout:
        line = line.rstrip("\n")
        if not line.strip():
            continue
        emit({"type": "log", "message": line})
        if any(marker in line for marker in ("Error", "error:", "terminating", "Traceback", "abort")):
            last_error = line.strip()

        step_preview = PREVIEW_STEP_RE.search(line)
        if step_preview:
            emit({"type": "artifact", "kind": "step", "path": step_preview.group(1)})
            continue  # keep SAVED_RE from adopting it as the job preview

        step_points = PREVIEW_POINTS_RE.search(line)
        if step_points:
            emit({"type": "artifact", "kind": "step_points", "path": step_points.group(1)})
            continue

        tqdm = TQDM_RE.search(line)
        if tqdm:
            span = SUBSTAGE_SPANS.get(tqdm.group(1).strip().lower())
            if span:
                lo, hi = span
                done, total_steps = int(tqdm.group(2)), max(int(tqdm.group(3)), 1)
                interpolated = lo + (hi - lo) * done // total_steps
                if interpolated > percent:
                    percent = interpolated
                    emit({"type": "progress", "stage": current_stage, "percent": percent,
                          "stage_percent": stage_percent_for(current_stage, percent),
                          "message": dict((s, l) for s, _, l in STAGES).get(current_stage, "")})
        else:
            for mark_re, mark_percent in SUBSTEP_MARKS:
                if mark_re.search(line) and mark_percent > percent:
                    percent = mark_percent
                    emit({"type": "progress", "stage": current_stage, "percent": percent,
                          "stage_percent": stage_percent_for(current_stage, percent),
                          "message": ""})
                    emit({"type": "progress", "stage": current_stage, "percent": percent,
                          "message": dict((s, l) for s, _, l in STAGES).get(current_stage, "")})
                    break

        for pattern, stage, entry_percent in STAGE_PATTERNS:
            if pattern.search(line):
                # Monotonic: heuristic matches must never move the stage backwards
                # (e.g. torch's "segment_reduce" warnings matching "segment").
                if stage != current_stage and stage_order.index(stage) > stage_order.index(current_stage):
                    current_stage = stage
                    percent = max(percent, entry_percent)
                    label = dict((s, l) for s, _, l in STAGES).get(stage, stage)
                    emit({"type": "stage_started", "stage": stage, "message": label})
                    emit({"type": "progress", "stage": stage, "percent": percent, "message": label})
                break

        saved = SAVED_RE.search(line)
        if saved:
            path = saved.group(1)
            if not os.path.isabs(path):
                path = os.path.join(repo, path)
            for ext in ("glb", "obj"):
                if path.endswith("." + ext) and os.path.isfile(path):
                    dest = os.path.join(job_dir, "output." + ext)
                    if os.path.abspath(path) != os.path.abspath(dest):
                        shutil.copy(path, dest)
                    if ext == "glb":
                        artifacts.append(dest)
                    emit({"type": "artifact", "kind": ext, "path": dest})

    rc = proc.wait()
    if rc != 0:
        if rc == -9:
            # SIGKILL: macOS terminated the engine under memory pressure
            # (or via Force Quit) — swap cannot grow on a nearly-full boot disk.
            message = ("macOS stopped the generation because the system ran out of memory headroom. "
                       "Free space on the internal disk (swap can't grow when it's full), close "
                       "memory-heavy apps like browsers, then try again. Ideally with the Fast "
                       "preset and Memory Mode → Efficiency in Settings.")
        elif rc == -6:
            # SIGABRT: native code aborted (uncaught C++/Metal error).
            if "GPU Timeout" in last_error:
                message = ("The GPU timed out mid-generation. macOS cancels kernels that run "
                           "too long when the GPU is under heavy load. Close intensive apps and "
                           "try again; the Fast preset needs the least GPU time per step.")
            else:
                message = (f"The engine aborted unexpectedly"
                           + (f": {last_error}" if last_error else "")
                           + ". Try again; see logs for the full output.")
        else:
            message = (f"{repo_name} exited with status {rc}"
                       + (f" ({last_error})" if last_error else "")
                       + ". Common causes: Hugging Face login/gated-model access missing "
                       "(dinov3), or out of memory. Try the Fast preset. See logs for the full output.")
        emit({"type": "error", "recoverable": True, "message": message})
        sys.exit(5)

    glb = os.path.join(job_dir, "output.glb")
    if not artifacts and os.path.isfile(output_base + ".glb"):
        if os.path.abspath(output_base + ".glb") != os.path.abspath(glb):
            shutil.copy(output_base + ".glb", glb)
        artifacts.append(glb)
        emit({"type": "artifact", "kind": "glb", "path": glb})
    if not artifacts:
        emit({"type": "error", "recoverable": True,
              "message": "Backend finished but produced no GLB. See logs."})
        sys.exit(6)

    # STL for 3D printing — geometry-only conversion via the engine venv's
    # trimesh (STL carries no textures by design).
    stl = os.path.join(job_dir, "output.stl")
    if artifacts and not os.path.isfile(stl):
        emit({"type": "log", "message": "Converting GLB → STL…"})
        convert = subprocess.run(
            [venv_python, "-c",
             "import sys, trimesh; trimesh.load(sys.argv[1], force='mesh').export(sys.argv[2])",
             artifacts[0], stl],
            capture_output=True, text=True, timeout=600)
        if convert.returncode == 0 and os.path.isfile(stl):
            emit({"type": "artifact", "kind": "stl", "path": stl})
        else:
            emit({"type": "log", "message": "STL conversion failed: " + (convert.stderr or "").strip()[-200:]})

    # Use the prepared image as the preview placeholder (real renders later).
    preview = os.path.join(job_dir, "preview.png")
    try:
        shutil.copy(args.image, preview)
        emit({"type": "artifact", "kind": "preview", "path": preview})
    except OSError:
        pass

    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})


def main():
    parser = argparse.ArgumentParser(description="3D Mate generation wrapper")
    parser.add_argument("--image", required=True, help="Input image path")
    parser.add_argument("--model-folder", help="Local TRELLIS.2 model folder (on the external SSD)")
    parser.add_argument("--output", required=True, help="Jobs/ parent folder (on the external SSD)")
    parser.add_argument("--job-id", help="Job folder name; generated when omitted")
    parser.add_argument("--preset", default="balanced", choices=sorted(SPEED))
    parser.add_argument("--geometry", default="standard", choices=["standard", "high"],
                        help="Geometry tier: standard keeps the preset's native "
                             "pipeline; high forces the 1024 cascade.")
    parser.add_argument("--geometry-only", action="store_true",
                        help="Skip texture generation entirely (texture SLat "
                             "sampling, UV unwrap, bake). Exports geometry as "
                             "GLB and STL, for 3D printing.")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--view", action="append", default=[],
                        help="Additional view image of the same object (repeatable, MLX only)")
    parser.add_argument("--engine", default="mps", choices=["mps", "mlx"],
                        help="Real backend engine: trellis-mac (PyTorch MPS) or trellis2-apple (MLX)")
    parser.add_argument("--mock", action="store_true", help="Simulate the pipeline (no model needed)")
    args = parser.parse_args()

    job_id = args.job_id or "job-" + uuid.uuid4().hex[:8]
    job_dir = os.path.join(args.output, job_id)
    os.makedirs(job_dir, exist_ok=True)

    emit({"type": "job_started", "job_id": job_id})

    if not os.path.isfile(args.image):
        emit({"type": "error", "message": "Input image not found: %s" % args.image, "recoverable": False})
        sys.exit(2)

    if args.mock:
        run_mock(args, job_dir, job_id)
    else:
        run_real(args, job_dir, job_id)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        emit({"type": "job_cancelled"})
        sys.exit(130)
    except BrokenPipeError:
        # Reader went away (e.g. cancelled from the app) — exit quietly.
        sys.exit(0)
