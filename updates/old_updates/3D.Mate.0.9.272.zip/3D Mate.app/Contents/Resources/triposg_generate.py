#!/usr/bin/env python3
"""3D Mate TripoSG runner. Emits the same JSONL protocol as the TRELLIS wrapper
(job_started / stage_started / progress / artifact / job_finished / error) so the
app consumes it identically.

TripoSG produces high-fidelity GEOMETRY (untextured). It runs on Apple Silicon
via MPS using the hierarchical CPU marching-cubes path (use_flash_decoder=False),
so the CUDA-only diso decoder is never touched. The dense raw mesh is decimated
with pymeshlab to a shippable face count.

The triposg package is imported from the installed engine pack (site-packages)
or, on a dev machine, from THREEDMATE_TRIPOSG_REPO."""
import argparse
import json
import os
import sys
import time


def emit(obj):
    print(json.dumps(obj), flush=True)


def simplify_mesh(mesh, n_faces):
    """Quadric edge-collapse decimation to n_faces (TripoSG's own recipe)."""
    if n_faces <= 0 or mesh.faces.shape[0] <= n_faces:
        return mesh
    import pymeshlab
    import trimesh
    ms = pymeshlab.MeshSet()
    ms.add_mesh(pymeshlab.Mesh(vertex_matrix=mesh.vertices, face_matrix=mesh.faces))
    ms.meshing_merge_close_vertices()
    ms.meshing_decimation_quadric_edge_collapse(targetfacenum=n_faces)
    m = ms.current_mesh()
    return trimesh.Trimesh(vertices=m.vertex_matrix(), faces=m.face_matrix())


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--image", required=True)
    p.add_argument("--output", default="")
    p.add_argument("--job-id", default="triposg")
    p.add_argument("--model-folder", default="")
    p.add_argument("--seed", default="0")
    p.add_argument("--steps", type=int, default=25)
    p.add_argument("--guidance", type=float, default=7.0)
    p.add_argument("--faces", type=int, default=50000)
    p.add_argument("--texture", action="store_true", help="run the MV-Adapter texture stage")
    p.add_argument("--texture-tier", default="auto", choices=["auto", "sdxl", "sd21"])
    p.add_argument("--texture-steps", type=int, default=25)
    args, _ = p.parse_known_args()

    start = time.time()
    emit({"type": "job_started", "job_id": args.job_id})

    # Prefer the installed pack (triposg already on the path); on a dev machine
    # fall back to the fork repo. Weights are self-contained, so stay offline.
    repo = os.environ.get("THREEDMATE_TRIPOSG_REPO", "")
    if repo and repo not in sys.path:
        sys.path.insert(0, repo)
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})
    if not os.path.exists(args.image):
        emit({"type": "error", "message": "Input image not found.", "recoverable": False})
        return 1

    try:
        import numpy as np
        import torch
        from PIL import Image
        from triposg.pipelines.pipeline_triposg import TripoSGPipeline
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"TripoSG runtime not available: {exc}", "recoverable": False})
        return 1

    device = "mps" if torch.backends.mps.is_available() else "cpu"

    emit({"type": "stage_started", "stage": "preparing_image", "message": "Preparing image"})
    # App-style input: the prepared RGBA cutout composited on white (no RMBG).
    img = Image.open(args.image).convert("RGBA")
    bg = Image.new("RGBA", img.size, (255, 255, 255, 255))
    rgb = Image.alpha_composite(bg, img).convert("RGB")

    emit({"type": "stage_started", "stage": "loading_model", "message": "Loading TripoSG"})
    local = args.model_folder
    model_src = local if (local and os.path.exists(os.path.join(local, "model_index.json"))) else "VAST-AI/TripoSG"
    pipe = TripoSGPipeline.from_pretrained(model_src).to(device, torch.float32)

    try:
        seed = int(args.seed)
    except (TypeError, ValueError):
        seed = 0

    emit({"type": "stage_started", "stage": "generating_structure", "message": "Generating shape"})
    emit({"type": "progress", "stage": "generating_structure", "percent": 30, "message": "Generating shape…"})
    with torch.no_grad():
        out = pipe(
            image=rgb,
            generator=torch.Generator(device=device).manual_seed(seed),
            num_inference_steps=args.steps,
            guidance_scale=args.guidance,
            use_flash_decoder=False,  # CPU hierarchical path; no CUDA diso
        )
    mesh = out.meshes[0] if hasattr(out, "meshes") else out[1][0]

    emit({"type": "stage_started", "stage": "generating_mesh", "message": "Building mesh"})
    emit({"type": "progress", "stage": "generating_mesh", "percent": 80, "message": "Simplifying mesh…"})
    mesh = simplify_mesh(mesh, args.faces)

    # Keep outward-facing normals (signed volume must be positive; see the
    # inside-out casebook). Harmless when already correct.
    try:
        if mesh.volume < 0:
            mesh.invert()
    except Exception:  # noqa: BLE001
        pass

    # Geometry GLB. When a texture pass follows this is an intermediate file, so
    # it does NOT emit the final "exporting_glb" stage (that would light Export
    # before Textures); the export stage fires once, at the end.
    job_folder = os.path.dirname(os.path.abspath(args.image))
    out_glb = os.path.join(job_folder, "output.glb")
    mesh.export(out_glb)
    emit({"type": "artifact", "kind": "glb", "path": out_glb})

    # STL for 3D printing, from the untextured geometry (STL carries no texture
    # by design). Emitted for every run, exactly like the TRELLIS.2 path, so a
    # printable mesh is always available beside the GLB.
    out_stl = os.path.join(job_folder, "output.stl")
    try:
        mesh.export(out_stl)
        emit({"type": "artifact", "kind": "stl", "path": out_stl})
    except Exception as exc:  # noqa: BLE001
        emit({"type": "log", "level": "warning",
              "message": f"STL export failed: {exc}"})

    # Optional texture pass. Geometry is already exported, so a texture failure is
    # recoverable: log it and finish with the untextured GLB rather than aborting.
    if args.texture:
        emit({"type": "stage_started", "stage": "baking_textures", "message": "Painting texture"})
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import texture_stage
            out_tex = os.path.join(job_folder, "output_textured.glb")
            texture_stage.run_texture(
                emit, out_glb, args.image, out_tex,
                tier=args.texture_tier, steps=args.texture_steps, seed=seed,
            )
            emit({"type": "artifact", "kind": "glb", "path": out_tex})
        except Exception as exc:  # noqa: BLE001
            emit({"type": "log", "level": "warning",
                  "message": f"Texture stage failed, shipping untextured geometry: {exc}"})

    # Single, final export stage (keeps the checklist monotonic: Structure ->
    # Mesh -> Textures -> Export). The app converts the GLB to USDZ after this.
    emit({"type": "stage_started", "stage": "exporting_glb", "message": "Finishing"})
    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})
    return 0


if __name__ == "__main__":
    sys.exit(main())
