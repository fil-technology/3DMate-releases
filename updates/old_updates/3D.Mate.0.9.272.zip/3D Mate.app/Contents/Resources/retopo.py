#!/usr/bin/env python3
"""3D Mate retopology: dense GLB -> clean quad OBJ, via trimesh cleanup + QuadriFlow,
then a texture rebake so the quad mesh carries the original's appearance.

Usage: retopo.py input.glb output.obj target_faces

Writes next to output.obj:
  model.obj   quad topology WITH per-corner UVs (mtllib/usemtl) for Blender/Maya
  model.mtl   references the baked texture
  model_texture.png   baked atlas
  model.glb   textured triangulated mesh (drives the in-app USDZ preview)

The rebake is best-effort: if anything in it fails we still emit the clean quad
OBJ untextured (recoverable, like the TripoSG texture stage), and the app falls
back to a clay preview.
"""
import sys, subprocess, tempfile, os, signal, threading, time
import trimesh, numpy as np
from trimesh.graph import connected_component_labels


# The running QuadriFlow child, tracked so we can stop it on cancel or when the
# app goes away (a retopo of a heavy model must never keep churning after the
# app is gone, which orphans it and pins the CPU).
_child = None


def _kill_child():
    c = _child
    if c is not None and c.poll() is None:
        try:
            c.terminate()
        except Exception:
            pass


def _install_guards():
    # Explicit cancel from the app arrives as SIGTERM: stop QuadriFlow and exit.
    def _on_term(signum, frame):
        _kill_child()
        os._exit(143)
    try:
        signal.signal(signal.SIGTERM, _on_term)
    except Exception:
        pass
    # App quit or crash reparents us to launchd (ppid 1): stop then too.
    start_ppid = os.getppid()
    def _watch():
        while True:
            time.sleep(1.0)
            if os.getppid() != start_ppid:
                _kill_child()
                os._exit(143)
    threading.Thread(target=_watch, daemon=True).start()


# The app passes QUADRIFLOW_BIN explicitly (the signed binary in the bundle).
# Fall back to a binary sitting next to this script (bundled flat in Resources)
# or under bin/ (source tree layout) so the script also runs standalone.
def _find_quadriflow():
    if os.environ.get("QUADRIFLOW_BIN"):
        return os.environ["QUADRIFLOW_BIN"]
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, "quadriflow"), os.path.join(here, "bin", "quadriflow")):
        if os.path.exists(cand):
            return cand
    return "quadriflow"
QF = _find_quadriflow()


def clean(src):
    m = trimesh.load(src, process=False, force='mesh')
    v, f = m.vertices, m.faces
    key = np.round(v, 4)                       # weld coincident (split) verts
    uniq, inv = np.unique(key, axis=0, return_inverse=True)
    f2 = inv[f]
    good = (f2[:, 0] != f2[:, 1]) & (f2[:, 1] != f2[:, 2]) & (f2[:, 0] != f2[:, 2])
    wm = trimesh.Trimesh(vertices=uniq, faces=f2[good], process=False)
    lab = connected_component_labels(wm.face_adjacency, node_count=len(wm.faces))
    counts = np.bincount(lab)
    wm.update_faces(lab == counts.argmax())    # keep largest component
    wm.remove_unreferenced_vertices()
    wm.fill_holes()                            # close boundaries for the solver
    return wm


# ---------------------------------------------------------------------------
# Texture rebake. Sample the textured source into a colored point cloud, then
# transfer color to the retopo mesh's fresh UV atlas by nearest surface point.
# ---------------------------------------------------------------------------

def _barycentric(p, tris):
    a, b, c = tris[:, 0], tris[:, 1], tris[:, 2]
    v0, v1, v2 = b - a, c - a, p - a
    d00 = (v0 * v0).sum(1); d01 = (v0 * v1).sum(1); d11 = (v1 * v1).sum(1)
    d20 = (v2 * v0).sum(1); d21 = (v2 * v1).sum(1)
    denom = d00 * d11 - d01 * d01
    denom = np.where(np.abs(denom) < 1e-20, 1e-20, denom)
    v = (d11 * d20 - d01 * d21) / denom
    w = (d00 * d21 - d01 * d20) / denom
    u = 1.0 - v - w
    bary = np.clip(np.stack([u, v, w], axis=1), 0.0, 1.0)
    s = bary.sum(1, keepdims=True)
    return bary / np.where(s == 0, 1, s)


def _sample_image(img, uv):
    h, w = img.shape[:2]
    u = np.clip(uv[:, 0], 0, 1) * (w - 1)
    v = (1.0 - np.clip(uv[:, 1], 0, 1)) * (h - 1)
    x0 = np.floor(u).astype(int); y0 = np.floor(v).astype(int)
    x1 = np.minimum(x0 + 1, w - 1); y1 = np.minimum(y0 + 1, h - 1)
    fx = (u - x0)[:, None]; fy = (v - y0)[:, None]
    imgf = img.astype(np.float64)
    c00 = imgf[y0, x0]; c10 = imgf[y0, x1]; c01 = imgf[y1, x0]; c11 = imgf[y1, x1]
    top = c00 * (1 - fx) + c10 * fx
    bot = c01 * (1 - fx) + c11 * fx
    return np.clip(top * (1 - fy) + bot * fy, 0, 255).astype(np.uint8)


def _source_pointcloud(src_path, n_samples):
    mesh = trimesh.load(src_path, process=False, force="mesh")
    vis = mesh.visual
    img = uv = None
    if isinstance(vis, trimesh.visual.TextureVisuals):
        uv = np.asarray(vis.uv) if vis.uv is not None else None
        mat = vis.material
        pil = getattr(mat, "baseColorTexture", None) or getattr(mat, "image", None)
        if pil is not None:
            img = np.asarray(pil.convert("RGB"), dtype=np.uint8)
    pts, fidx = trimesh.sample.sample_surface(mesh, n_samples)
    pts = np.asarray(pts, dtype=np.float64)
    fidx = np.asarray(fidx)
    if img is not None and uv is not None:
        tris = mesh.vertices[mesh.faces[fidx]]
        bary = _barycentric(pts, tris)
        face_uv = uv[mesh.faces[fidx]]
        suv = (bary[:, :, None] * face_uv).sum(axis=1)
        cols = _sample_image(img, suv)
    else:
        vc = None
        try:
            vc = np.asarray(mesh.visual.to_color().vertex_colors)[:, :3]
        except Exception:
            pass
        if vc is None:
            cols = np.full((len(pts), 3), 180, dtype=np.uint8)
        else:
            tri_v = mesh.vertices[mesh.faces[fidx]]
            bary = _barycentric(pts, tri_v)
            cols = np.clip((bary[:, :, None] * vc[mesh.faces[fidx]].astype(np.float64)).sum(1),
                           0, 255).astype(np.uint8)
    return pts, cols


def _parse_obj(path):
    """Read a QuadriFlow OBJ: vertex positions + polygon faces (0-based)."""
    verts, faces = [], []
    with open(path) as fh:
        for line in fh:
            p = line.split()
            if not p:
                continue
            if p[0] == 'v':
                verts.append([float(x) for x in p[1:4]])
            elif p[0] == 'f':
                faces.append([int(t.split('/')[0]) - 1 for t in p[1:]])
    return np.asarray(verts, dtype=np.float64), faces


def _triangulate(faces):
    """Fan-triangulate polygons; remember each tri's (face index, corner slots)."""
    tris, owners = [], []
    for fi, face in enumerate(faces):
        for k in range(1, len(face) - 1):
            tris.append([face[0], face[k], face[k + 1]])
            owners.append((fi, (0, k, k + 1)))
    return np.asarray(tris, dtype=np.uint32), owners


def _rasterize(positions, faces, uvs, size):
    filled = np.zeros((size, size), dtype=bool)
    world = np.zeros((size, size, 3), dtype=np.float64)
    px = uvs[:, 0] * (size - 1)
    py = (1.0 - uvs[:, 1]) * (size - 1)
    P = np.stack([px, py], axis=1)
    for tri in faces:
        p0, p1, p2 = P[tri]
        w0, w1, w2 = positions[tri]
        minx = max(int(np.floor(min(p0[0], p1[0], p2[0]))), 0)
        maxx = min(int(np.ceil(max(p0[0], p1[0], p2[0]))), size - 1)
        miny = max(int(np.floor(min(p0[1], p1[1], p2[1]))), 0)
        maxy = min(int(np.ceil(max(p0[1], p1[1], p2[1]))), size - 1)
        if maxx < minx or maxy < miny:
            continue
        gx, gy = np.meshgrid(np.arange(minx, maxx + 1), np.arange(miny, maxy + 1))
        denom = (p1[1] - p2[1]) * (p0[0] - p2[0]) + (p2[0] - p1[0]) * (p0[1] - p2[1])
        if abs(denom) < 1e-12:
            continue
        a = ((p1[1] - p2[1]) * (gx - p2[0]) + (p2[0] - p1[0]) * (gy - p2[1])) / denom
        b = ((p2[1] - p0[1]) * (gx - p2[0]) + (p0[0] - p2[0]) * (gy - p2[1])) / denom
        c = 1 - a - b
        eps = -1e-4
        inside = (a >= eps) & (b >= eps) & (c >= eps)
        if not inside.any():
            continue
        ai, bi, ci = a[inside], b[inside], c[inside]
        pos = ai[:, None] * w0 + bi[:, None] * w1 + ci[:, None] * w2
        yy, xx = gy[inside], gx[inside]
        world[yy, xx] = pos
        filled[yy, xx] = True
    return filled, world


def _dilate(atlas, filled, passes):
    out = atlas.copy()
    fill = filled.copy()
    H, W = filled.shape
    for _ in range(passes):
        holes = ~fill
        if not holes.any():
            break
        acc = np.zeros((H, W, 3), dtype=np.float64)
        cnt = np.zeros((H, W), dtype=np.float64)
        for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)):
            src_valid = np.roll(np.roll(fill, dy, 0), dx, 1)
            src_col = np.roll(np.roll(out, dy, 0), dx, 1)
            take = src_valid & holes
            acc[take] += src_col[take]
            cnt[take] += 1
        newly = holes & (cnt > 0)
        out[newly] = (acc[newly] / cnt[newly, None]).astype(np.uint8)
        fill[newly] = True
    return out


def _write_textured_obj(obj_path, verts, faces, face_uv, tex_name, mtl_name):
    """Quad OBJ with per-corner UVs referencing the baked texture."""
    mtl_path = os.path.join(os.path.dirname(obj_path), mtl_name)
    with open(mtl_path, "w") as fh:
        fh.write("newmtl retopo\nKa 0 0 0\nKd 1 1 1\nKs 0 0 0\nd 1\nillum 1\n")
        fh.write(f"map_Kd {tex_name}\n")
    lines = [f"mtllib {mtl_name}", "usemtl retopo"]
    for v in verts:
        lines.append(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}")
    vt = []          # flat list of (u, v); 1-based index in OBJ
    vt_index = {}    # (fi, slot) -> vt id
    for fi, face in enumerate(faces):
        for slot in range(len(face)):
            uv = face_uv.get((fi, slot))
            if uv is None:
                uv = (0.0, 0.0)
            vt.append(uv)
            vt_index[(fi, slot)] = len(vt)
    for u, v in vt:
        lines.append(f"vt {u:.6f} {v:.6f}")
    for fi, face in enumerate(faces):
        parts = [f"{idx + 1}/{vt_index[(fi, slot)]}" for slot, idx in enumerate(face)]
        lines.append("f " + " ".join(parts))
    tmp = obj_path + ".tmp"
    with open(tmp, "w") as fh:
        fh.write("\n".join(lines) + "\n")
    os.replace(tmp, obj_path)


def rebake_texture(src, quad_obj, out_obj, tex_size=1024, samples=1_200_000, dilate=8):
    """Bake `src`'s appearance onto the quad mesh. Returns True on success."""
    import xatlas
    from PIL import Image
    from scipy.spatial import cKDTree

    verts, faces = _parse_obj(quad_obj)
    if len(verts) == 0 or not faces:
        return False
    tris, owners = _triangulate(faces)

    vmapping, indices, uvs = xatlas.parametrize(verts.astype(np.float32), tris)
    positions = verts[vmapping].astype(np.float64)
    indices = indices.astype(np.int64)
    uvs = uvs.astype(np.float64)

    # atlas tri i corresponds to input tri i -> map UVs back to quad corners.
    face_uv = {}
    for i, (fi, slots) in enumerate(owners):
        for slot, av in zip(slots, indices[i]):
            face_uv[(fi, slot)] = (float(uvs[av][0]), float(uvs[av][1]))

    pts, cols = _source_pointcloud(src, samples)
    tree = cKDTree(pts)

    filled, world = _rasterize(positions, indices, uvs, tex_size)
    if not filled.any():
        return False
    atlas = np.zeros((tex_size, tex_size, 3), dtype=np.uint8)
    # Leave headroom for the UI: half the cores, not all of them (workers=-1).
    workers = max(1, (os.cpu_count() or 4) // 2)
    _, idx = tree.query(world[filled], k=1, workers=workers)
    atlas[filled] = cols[idx]
    atlas = _dilate(atlas, filled, dilate)

    out_dir = os.path.dirname(out_obj)
    tex_name = "model_texture.png"
    Image.fromarray(atlas, "RGB").save(os.path.join(out_dir, tex_name))
    _write_textured_obj(out_obj, verts, faces, face_uv, tex_name, "model.mtl")

    # Textured triangulated GLB for the in-app preview / USDZ.
    img = Image.fromarray(atlas, "RGB")
    mat = trimesh.visual.material.PBRMaterial(baseColorTexture=img,
                                              metallicFactor=0.0, roughnessFactor=0.9)
    tv = trimesh.visual.TextureVisuals(uv=uvs, material=mat, image=img)
    trimesh.Trimesh(vertices=positions, faces=indices, visual=tv, process=False) \
        .export(os.path.join(out_dir, "model.glb"))

    covered = 100.0 * int(filled.sum()) / (tex_size * tex_size)
    print(f"BAKED texels={int(filled.sum())} coverage={covered:.1f}% verts={len(verts)}")
    return True


def _face_stats(path):
    q = t = 0
    for line in open(path):
        p = line.split()
        if p and p[0] == 'f':
            n = len(p) - 1
            q += (n == 4); t += (n == 3)
    return q, t


def run_quadriflow(tin, out, target):
    """Run QuadriFlow, retrying nearby face counts until one produces output.

    QuadriFlow's integer index-map solver flakes ("wrong init N M!") at certain
    resolutions and exits 0 without writing a file, even on clean, watertight
    meshes. The failure is resolution dependent, so a small nudge to the target
    face count usually lands on a solvable configuration. We try the requested
    count first, then alternating nudges out to +/-20%.
    """
    global _child
    mults = [1.0, 0.95, 1.05, 0.90, 1.10, 0.85, 1.15, 0.80, 1.20]
    for i, mult in enumerate(mults):
        print(f"PROGRESS remeshing {i + 1}", flush=True)
        faces = max(1000, int(round(target * mult / 100.0)) * 100)
        try:
            os.remove(out)
        except OSError:
            pass
        _child = subprocess.Popen([QF, "-i", tin, "-o", out, "-f", str(faces)],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        _child.wait()
        _child = None
        if os.path.exists(out) and os.path.getsize(out) > 0:
            if i > 0:
                print(f"quadriflow ok at faces={faces} (attempt {i + 1})")
            return True
    return False


def main():
    # Retopology is a background convenience, not the main event: run it nicely
    # so a heavy mesh (QuadriFlow retries + the multi-core bake) cannot starve
    # the UI and make the whole Mac feel glitchy.
    try:
        os.nice(10)
    except Exception:
        pass
    _install_guards()
    src, out, target = sys.argv[1], sys.argv[2], int(sys.argv[3])
    print("PROGRESS preparing", flush=True)
    wm = clean(src)
    tin = tempfile.mktemp(suffix=".obj")
    quad_tmp = tempfile.mktemp(suffix=".obj")
    wm.export(tin)
    if not run_quadriflow(tin, quad_tmp, target):
        for p in (tin, quad_tmp):
            try:
                os.remove(p)
            except OSError:
                pass
        # Last line becomes the app's error text; keep it human.
        print("This model's shape is too tangled for the quad remesher. "
              "Try a different model, or a different detail level.")
        sys.exit(2)
    q, t = _face_stats(quad_tmp)
    print(f"OK cleaned_faces={len(wm.faces)} -> quads={q} tris={t} "
          f"quad%={100 * q / max(q + t, 1):.1f}")

    print("PROGRESS texturing", flush=True)
    baked = False
    try:
        baked = rebake_texture(src, quad_tmp, out)
    except Exception as e:  # texture is best-effort; ship the clean quads regardless
        print(f"WARN texture rebake failed: {type(e).__name__}: {e}")
    if not baked:
        # Fall back to the plain quad OBJ (no UVs / texture).
        import shutil
        shutil.copyfile(quad_tmp, out)
        print("WARN shipped untextured quad OBJ")

    for p in (tin, quad_tmp):
        try:
            os.remove(p)
        except OSError:
            pass


if __name__ == "__main__":
    main()
