#!/usr/bin/env python3
"""3D Mate TripoSR runner. Emits the same JSONL protocol as the TRELLIS wrapper
(job_started / stage_started / progress / artifact / job_finished / error) so the
app consumes it identically. Runs TripoSR on CPU, bakes a texture when moderngl
is present (else vertex colors), and fixes the inside-out orientation.

The tsr package lives in a repo the app points at via THREEDMATE_TRIPOSR_REPO
(dev). A bundled TripoSR engine pack for customers is a follow-up."""
import argparse
import json
import os
import sys
import time


def emit(obj):
    print(json.dumps(obj), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--image", required=True)
    p.add_argument("--output", default="")
    p.add_argument("--job-id", default="triposr")
    p.add_argument("--model-folder", default="")
    p.add_argument("--seed", default="0")
    p.add_argument("--mc-resolution", type=int, default=256)
    p.add_argument("--texture-resolution", type=int, default=1024)
    args, _ = p.parse_known_args()

    start = time.time()
    emit({"type": "job_started", "job_id": args.job_id})

    repo = os.environ.get("THREEDMATE_TRIPOSR_REPO", "/Volumes/3DMate-Dev/BackendCandidates/triposr")
    if repo and repo not in sys.path:
        sys.path.insert(0, repo)
    # The DINO image tokenizer fetches facebook/dino-vitb16's config.json (just
    # the arch spec; the ViT weights live in TripoSR's own ckpt). The app seeds
    # that file into the HF cache as a dependency, so stay fully offline and load
    # it locally rather than reaching out to Hugging Face on every generation.
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})
    if not os.path.exists(args.image):
        emit({"type": "error", "message": "Input image not found.", "recoverable": False})
        return 1

    try:
        import numpy as np
        import torch
        import trimesh
        from PIL import Image
        from tsr.system import TSR
        from tsr.utils import resize_foreground
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"TripoSR runtime not available: {exc}", "recoverable": False})
        return 1

    device = "cpu"

    emit({"type": "stage_started", "stage": "preparing_image", "message": "Preparing image"})
    rgba_img = resize_foreground(Image.open(args.image).convert("RGBA"), 0.85)
    rgba = np.array(rgba_img).astype(np.float32) / 255.0
    rgb = rgba[:, :, :3] * rgba[:, :, 3:4] + (1 - rgba[:, :, 3:4]) * 0.5
    image = Image.fromarray((rgb * 255.0).astype(np.uint8))

    emit({"type": "stage_started", "stage": "loading_model", "message": "Loading TripoSR"})
    local = args.model_folder
    model_src = local if (local and os.path.exists(os.path.join(local, "model.ckpt"))) else "stabilityai/TripoSR"
    model = TSR.from_pretrained(model_src, config_name="config.yaml", weight_name="model.ckpt")
    model.renderer.set_chunk_size(8192)
    model.to(device)

    emit({"type": "progress", "stage": "generating_mesh", "percent": 35, "message": "Generating shape…"})
    with torch.no_grad():
        scene_codes = model([image], device=device)

    emit({"type": "progress", "stage": "generating_mesh", "percent": 60, "message": "Extracting mesh…"})
    try:
        from tsr.bake_texture import bake_texture
        emit({"type": "stage_started", "stage": "baking_textures", "message": "Baking texture"})
        mesh = model.extract_mesh(scene_codes, False, resolution=args.mc_resolution)[0]
        bake = bake_texture(mesh, model, scene_codes[0], args.texture_resolution)
        tex = Image.fromarray((bake["colors"] * 255.0).astype(np.uint8)).transpose(Image.FLIP_TOP_BOTTOM)
        tm = trimesh.Trimesh(
            vertices=mesh.vertices[bake["vmapping"]],
            faces=bake["indices"],
            visual=trimesh.visual.TextureVisuals(uv=bake["uvs"], image=tex),
            process=False,
        )
    except Exception as exc:  # noqa: BLE001
        emit({"type": "log", "message": f"Texture bake unavailable ({exc}); using vertex colors"})
        tm = model.extract_mesh(scene_codes, True, resolution=args.mc_resolution)[0]

    # TripoSR's marching-cubes axis swap yields an inside-out mesh; flip it.
    if tm.volume < 0:
        tm.invert()

    emit({"type": "stage_started", "stage": "exporting_glb", "message": "Exporting model"})
    job_folder = os.path.dirname(os.path.abspath(args.image))
    out_glb = os.path.join(job_folder, "output.glb")
    tm.export(out_glb)
    emit({"type": "artifact", "kind": "glb", "path": out_glb})

    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})
    return 0


if __name__ == "__main__":
    sys.exit(main())
