#!/usr/bin/env python3
"""3D Mate SAM 3D Objects runner. Emits the same JSONL protocol as the TRELLIS
wrapper (job_started / stage_started / progress / artifact / job_finished / error)
so the app consumes it identically.

Meta's SAM 3D Objects, converted to MLX, runs through the `mlx-spatial-sam3d`
CLI (the `mlx-spatial` package, pure MLX, no CUDA, no torch). We drive that CLI
as a subprocess under the same interpreter's bin dir, so the pack ships only
mlx-spatial and its handful of deps.

SAM3D takes an image plus a binary object mask. The app hands us the prepared
RGBA cutout (background already removed), so we derive both: the RGB is the
image, the alpha thresholded is the mask. We ask the CLI for a textured GLB mesh
(`--glb-texture gaussian`), which flows through the app's existing GLB/USDZ
export, optimize, and viewer stages unchanged. The Gaussian-splat PLY is written
alongside but is not surfaced as an app artifact.

Three things the spike (2026-07-23, M1 Pro 32 GB) pinned down and that this
wrapper depends on:
  * The CLI validates that every output path resolves under `<cwd>/outputs/`, so
    we run it with cwd set to the job folder and write to `outputs/…`, then move
    the GLB up to the job folder where the app expects `output.glb`.
  * MoGe (the pointmap preprocessor) loads from `--moge-root <bundle>/moge`.
  * The FlexiCubes mesh guard is a dense worst-case estimate (it assumes every
    cube in the 256^3 grid is a surface cube, ~44 GB) while the real extraction
    touches only the sparse surface shell (~13 GB peak observed). `large` lifts
    that guard so the mesh path isn't falsely blocked; the actual memory fits a
    32 GB Mac. Overridable via THREEDMATE_SAM3D_MEMORY_PROFILE.

The mlx-spatial package lives on the pack python's path (or a dev spike venv the
app points at via THREEDMATE_SAM3D_PYTHON)."""
import argparse
import json
import os
import subprocess
import sys
import threading
import time


def emit(obj):
    print(json.dumps(obj), flush=True)


def _memory_profile():
    """The CLI's --memory-profile. Defaults to `large`, which is what makes the
    mesh path usable: its FlexiCubes guard is a dense worst-case that blocks
    `safe`/`balanced` even though the real extraction fits ~13 GB. Overridable."""
    override = os.environ.get("THREEDMATE_SAM3D_MEMORY_PROFILE", "").strip()
    if override in ("safe", "balanced", "large"):
        return override
    return "large"


def _console_script(name):
    """The mlx-spatial console script sits next to the running interpreter
    (pack/<ver>/bin or the dev venv's bin). Fall back to PATH resolution."""
    candidate = os.path.join(os.path.dirname(sys.executable), name)
    if os.path.exists(candidate):
        return candidate
    return name


def _prepare_image_and_mask(prepared_path, work_dir):
    """Split the prepared RGBA cutout into an RGB image and a binary mask SAM3D
    can consume. Returns (image_path, mask_path)."""
    from PIL import Image

    im = Image.open(prepared_path)
    image_path = os.path.join(work_dir, "sam3d_image.png")
    mask_path = os.path.join(work_dir, "sam3d_mask.png")
    if im.mode == "RGBA":
        rgb = im.convert("RGB")
        alpha = im.split()[3]
        # Binary mask: anything meaningfully opaque is the object. The cutout's
        # alpha is already a clean matte, so a mid threshold is safe.
        mask = alpha.point(lambda a: 255 if a > 127 else 0).convert("L")
        rgb.save(image_path)
        mask.save(mask_path)
    else:
        # No alpha to work from: treat the whole frame as the object. SAM3D still
        # runs, just without a tight mask (the app normally supplies a cutout).
        im.convert("RGB").save(image_path)
        Image.new("L", im.size, 255).save(mask_path)
    return image_path, mask_path


def _reorient_glb_y_up(src, dst):
    """SAM3D emits the mesh in its own frame, rotated ~90 degrees from glTF's
    Y-up, so the app (and every glTF viewer) shows it lying on its side and, mis-
    oriented, it sinks below the studio ground plane and vanishes. A fixed -90
    degree rotation about X maps SAM3D's frame to Y-up. Verified upright on
    multiple subjects (2026-07-24). We wrap the scene's root nodes under one new
    node carrying the rotation quaternion, so no vertex/normal decoding is needed
    and any node transforms already present compose correctly. Stdlib only (the
    pack has no trimesh)."""
    import struct

    # -90 degrees about X: quaternion [x,y,z,w] = [sin(-45deg), 0, 0, cos(-45deg)].
    q = [-0.7071067811865476, 0.0, 0.0, 0.7071067811865476]
    data = open(src, "rb").read()
    magic, _ver, length = struct.unpack("<III", data[:12])
    if magic != 0x46546C67:
        # Not a GLB we understand; pass it through unchanged rather than fail.
        os.replace(src, dst)
        return
    off = 12
    chunks = []
    while off < length:
        clen, ctype = struct.unpack("<II", data[off:off + 8]); off += 8
        chunks.append([ctype, bytearray(data[off:off + clen])]); off += clen
    g = json.loads(chunks[0][1].decode("utf-8"))
    scene = g.get("scene", 0)
    roots = g["scenes"][scene].get("nodes", [])
    new_index = len(g["nodes"])
    g["nodes"].append({"name": "sam3d_reorient", "rotation": q, "children": roots})
    g["scenes"][scene]["nodes"] = [new_index]
    new_json = json.dumps(g, separators=(",", ":")).encode("utf-8")
    while len(new_json) % 4:
        new_json += b" "
    chunks[0][1] = bytearray(new_json)
    body = bytearray()
    for ctype, cdata in chunks:
        pad = b" " if ctype == 0x4E4F534A else b"\x00"
        while len(cdata) % 4:
            cdata += pad
        body += struct.pack("<II", len(cdata), ctype) + cdata
    out = struct.pack("<III", 0x46546C67, 2, 12 + len(body)) + body
    with open(dst, "wb") as fh:
        fh.write(out)
    try:
        os.remove(src)
    except OSError:
        pass


def _heartbeat(stop_event):
    """The CLI prints its diagnostics only at the end, so a ~10 minute run is
    otherwise silent. Emit a slowly rising progress so the app doesn't look
    stuck. Caps below 90 so the real finish still moves it forward."""
    start = time.time()
    # Rough shape of a run: sparse-structure, then the long SLat + decoders, then
    # mesh extraction. Ramp over ~10 minutes toward 85%.
    while not stop_event.wait(15):
        elapsed = time.time() - start
        pct = min(0.85, 0.20 + elapsed / 720.0 * 0.65)
        stage = "generating_mesh" if pct < 0.7 else "baking_textures"
        msg = "Refining structured latents…" if pct < 0.7 else "Building textured mesh…"
        emit({"type": "progress", "stage": stage, "percent": round(pct * 100), "message": msg})


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--image", required=True)
    p.add_argument("--output", default="")
    p.add_argument("--job-id", default="sam3d")
    p.add_argument("--model-folder", default="")
    p.add_argument("--seed", default="0")
    args, _ = p.parse_known_args()

    start = time.time()
    emit({"type": "job_started", "job_id": args.job_id})

    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})
    if not os.path.exists(args.image):
        emit({"type": "error", "message": "Input image not found.", "recoverable": False})
        return 1

    # The bundle root holds checkpoints/pipeline.yaml plus the bundled MoGe under
    # moge/. The app streams it into Models/SAM3D and passes that as --model-folder.
    root = args.model_folder
    pipeline = os.path.join(root, "checkpoints", "pipeline.yaml") if root else ""
    moge_root = os.path.join(root, "moge") if root else ""
    if not root or not os.path.exists(pipeline):
        emit({"type": "error",
              "message": "The SAM 3D Objects weights aren't installed yet.",
              "recoverable": False})
        return 1

    job_folder = os.path.dirname(os.path.abspath(args.image))

    try:
        emit({"type": "stage_started", "stage": "preparing_image", "message": "Preparing image"})
        image_path, mask_path = _prepare_image_and_mask(args.image, job_folder)
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Couldn't prepare the image: {exc}", "recoverable": False})
        return 1

    # The CLI requires output paths under <cwd>/outputs, so run it from the job
    # folder and write there, then move the GLB up to where the app expects it.
    out_dir = os.path.join(job_folder, "outputs")
    os.makedirs(out_dir, exist_ok=True)
    rel_ply = os.path.join("outputs", "gaussians.ply")
    rel_glb = os.path.join("outputs", "object.glb")
    rel_trace = os.path.join("outputs", "sam3d_trace.json")
    final_glb = os.path.join(job_folder, "output.glb")

    script = _console_script("mlx-spatial-sam3d")
    cmd = [
        script, "reconstruct", root, image_path,
        "--mask", mask_path,
        "--moge-root", moge_root,
        "--output", rel_ply,
        "--glb-output", rel_glb,
        "--glb-texture", "gaussian",
        "--seed", str(args.seed),
        "--memory-profile", _memory_profile(),
        "--trace-output", rel_trace,
    ]

    emit({"type": "progress", "stage": "generating_mesh", "percent": 20,
          "message": "Reconstructing shape…"})

    env = dict(os.environ)
    env.setdefault("PYTHONUNBUFFERED", "1")
    stop_event = threading.Event()
    beat = threading.Thread(target=_heartbeat, args=(stop_event,), daemon=True)
    beat.start()
    try:
        proc = subprocess.Popen(cmd, cwd=job_folder, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, env=env, bufsize=1)
    except Exception as exc:  # noqa: BLE001
        stop_event.set()
        emit({"type": "error", "message": f"SAM 3D Objects runtime not available: {exc}",
              "recoverable": False})
        return 1

    tail = []
    for line in proc.stdout:
        line = line.rstrip()
        if not line:
            continue
        tail.append(line)
        del tail[:-40]
        emit({"type": "log", "message": line})
    proc.wait()
    stop_event.set()

    produced = os.path.join(job_folder, rel_glb)
    if proc.returncode != 0 or not os.path.exists(produced):
        detail = " ".join(tail[-6:]) or f"exited with status {proc.returncode}"
        emit({"type": "error", "message": f"SAM 3D Objects reconstruction failed. {detail}",
              "recoverable": False})
        return 1

    emit({"type": "stage_started", "stage": "exporting_glb", "message": "Exporting model"})
    # Rotate into glTF Y-up so the model stands upright and rests on the ground
    # plane (SAM3D's native frame is ~90 degrees off; see _reorient_glb_y_up).
    _reorient_glb_y_up(produced, final_glb)
    emit({"type": "artifact", "kind": "glb", "path": final_glb})
    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})
    return 0


if __name__ == "__main__":
    sys.exit(main())
