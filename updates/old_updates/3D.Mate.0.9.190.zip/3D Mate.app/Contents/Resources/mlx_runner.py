#!/usr/bin/env python3
"""Headless MLX generation for 3D Mate.

Runs inside the trellis2-apple checkout with its .venv (cwd must be the repo).
Progress lines are formatted to match the stage regexes in
trellismac_generate.py.

Memory contract: post-processing needs only the extracted mesh (independent
CPU tensors), so the pipeline. Several GB of weights. Is released before
baking. That keeps peak memory inside what a 16 GB machine can swap; holding
weights through the bake is what got earlier runs SIGKILLed.

M1 note: the only Metal-bake op unsupported on M1-family GPUs is cumesh's
simplify kernel (a 64-bit atomic min; the driver misreports it as a float
atomic). Pre-decimating on CPU keeps the mesh below the decimation target so
to_glb never invokes simplify, and the rest of the Metal bake. UV unwrap and
rasterized texture bake. Runs fine and beats the KDTree fallback on quality.
"""
import argparse
import gc
import os
import sys
import time


def log(message):
    print(message, flush=True)


def to_numpy(value, dtype=None):
    import numpy as np
    if hasattr(value, "cpu"):  # torch tensor
        value = value.cpu().float().numpy()
    array = np.asarray(value)
    return array.astype(dtype) if dtype is not None else array


def metal_simplify_supported():
    """Probe cumesh's simplify kernel on a tetrahedron (~40 ms). Trying the
    real mesh instead would first copy it to MPS and build a full BVH."""
    import torch
    try:
        import cumesh
        probe = cumesh.CuMesh()
        probe.init(torch.tensor([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=torch.float32),
                   torch.tensor([[0, 2, 1], [0, 1, 3], [0, 3, 2], [1, 2, 3]], dtype=torch.int32))
        probe.simplify_step(1e-2, 1e-3, 1e-8, False)
        return True
    except Exception:
        return False


def release_pipeline_memory():
    """Free MLX weight buffers after the pipeline refs are dropped.
    gc.collect() is mandatory: mx.compile callables capture bound methods,
    so the flow models sit in reference cycles plain refcounting can't free."""
    gc.collect()
    try:
        import mlx.core as mx
        mx.clear_cache()
        active_mb = mx.get_active_memory() / (1 << 20)
        log(f"Released pipeline weights (MLX active: {active_mb:.0f} MB)")
    except Exception:
        pass
    try:
        import torch
        if torch.backends.mps.is_available():
            torch.mps.empty_cache()
    except Exception:
        pass


def kdtree_bake(verts, faces, voxel_coords, voxel_attrs, origin, voxel_size,
                output_base, texture_size):
    """Port of trellis-mac's fallback bake (simplify → xatlas → KDTree)."""
    import numpy as np
    sibling = os.path.abspath(os.path.join(os.getcwd(), "..", "trellis-mac"))
    sys.path.insert(0, sibling)
    from backends.texture_baker import uv_unwrap, bake_texture, export_glb_with_texture
    import fast_simplification

    target = int(os.environ.get("TRELLIS_BAKE_TARGET_FACES", "100000"))
    if len(faces) > target:
        log(f"  Simplifying mesh: {len(faces):,} -> ~{target:,} faces")
        verts, faces = fast_simplification.simplify(verts, faces, 1.0 - target / len(faces))
    log("  UV unwrapping with xatlas...")
    new_verts, new_faces, uvs, _ = uv_unwrap(verts, faces)
    log(f"Baking PBR textures via KDTree ({texture_size}x{texture_size})...")
    base_color, mr, _ = bake_texture(new_verts, new_faces, uvs,
                                     voxel_coords, voxel_attrs, origin, voxel_size,
                                     texture_size=texture_size)
    glb_path = output_base + ".glb"
    export_glb_with_texture(new_verts, new_faces, uvs, base_color, mr, glb_path)
    log(f"Saved: {glb_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("image", nargs="+")  # 2-4 paths = views of one object
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", default="output_3d")
    parser.add_argument("--pipeline-type", default="512", choices=["512", "1024_cascade", "1536_cascade"])
    parser.add_argument("--texture-size", type=int, default=1024)
    args = parser.parse_args()

    # Bound Metal command-buffer packing BEFORE mlx loads (read once at
    # Device construction): long lazy chains + weight-load event-waits in
    # one buffer trip the GPU watchdog on M1 (kIOGPUCommandBufferCallback-
    # ErrorTimeout → SIGABRT). Export different values to override.
    os.environ.setdefault("MLX_MAX_OPS_PER_BUFFER", "4")
    os.environ.setdefault("MLX_MAX_MB_PER_BUFFER", "16")

    # Un-suppress the decoder's "[MLX] VAE stage i/5: N=…" lines — the only
    # visibility into per-stage token growth when diagnosing decode issues.
    import logging
    logging.basicConfig(level=logging.INFO, stream=sys.stdout, format="%(message)s")

    sys.path.insert(0, os.getcwd())
    import numpy as np
    import torch
    from PIL import Image
    import mlx.core as mx
    import o_voxel

    # set_cache_limit takes bytes; "0" is meaningful (efficiency memory mode
    # disables the buffer cache entirely, trading speed for headroom).
    cache_limit_mb = os.environ.get("TRELLIS_MLX_CACHE_LIMIT_MB")
    if cache_limit_mb is not None:
        mx.set_cache_limit(int(cache_limit_mb) * 1024 * 1024)

    # Per-stage weight release + fp16 DINOv3 (see mlx_backend patches): at
    # most one 2.4 GB flow model stays materialized instead of an ~11 GB set.
    # Must be set before mlx_backend.pipeline is imported; export 0 to opt out.
    os.environ.setdefault("TRELLIS_MLX_STAGE_LOAD", "1")
    os.environ.setdefault("TRELLIS_MLX_DINOV3_FP16", "1")

    log("Loading pipeline (MLX)...")
    from mlx_backend.pipeline import create_mlx_pipeline
    weights = os.environ.get("TRELLIS2_MODEL", "microsoft/TRELLIS.2-4B")
    pipeline = create_mlx_pipeline(weights_path=weights)

    log("Preprocessing image")
    views = [pipeline.preprocess_image(Image.open(p)) for p in args.image]
    image = views if len(views) > 1 else views[0]
    if len(views) > 1:
        log(f"Multi-view conditioning: {len(views)} views")

    # Microsoft's default is 12 steps; the Fast preset requests 8 (draft
    # quality) via the wrapper — sampling is the dominant, complexity-scaled
    # cost, and steps are the only lever that cuts it proportionally.
    steps = int(os.environ.get("TRELLIS_MLX_STEPS", "12"))
    sparse_params = {"steps": steps, "guidance_strength": 7.5}
    shape_params = {"steps": steps, "guidance_strength": 7.5}
    if os.environ.get("TRELLIS_MLX_NARROW_GUIDANCE") == "1":
        # CFG doubles the model passes per step inside the interval; the
        # defaults ([0.6, 1.0], rescaled t) run ~2x passes late in the
        # schedule — narrowing trades a little image adherence for speed.
        sparse_params["guidance_interval"] = [0.875, 1.0]
        shape_params["guidance_interval"] = [0.857, 1.0]

    log("Sampling sparse structure (MLX)")
    t0 = time.time()
    meshes = pipeline.run(
        image,
        seed=args.seed,
        # The image is preprocessed above; run() would otherwise preprocess
        # again — and since preprocess outputs RGB, the alpha check fails and
        # a second 844 MB BiRefNet pass runs, discarding the curated cutout.
        preprocess_image=False,
        sparse_structure_sampler_params=sparse_params,
        shape_slat_sampler_params=shape_params,
        tex_slat_sampler_params={"steps": steps, "guidance_strength": 1.0},
        pipeline_type=args.pipeline_type,
    )
    mesh = meshes[0]
    log(f"Mesh extraction done: {int(mesh.faces.shape[0]):,} raw faces in {time.time() - t0:.1f}s")

    # Everything the bakers need, as independent CPU tensors/values.
    vertices, faces = mesh.vertices, mesh.faces
    attrs, coords, layout = mesh.attrs, mesh.coords, mesh.layout
    voxel_size = float(mesh.voxel_size)
    origin = to_numpy(mesh.origin, np.float32) if hasattr(mesh, "origin") \
        else np.array([-0.5, -0.5, -0.5], np.float32)
    del pipeline, meshes, mesh, image
    release_pipeline_memory()

    target = int(os.environ.get("TRELLIS_BAKE_TARGET_FACES", "100000"))
    output_base = args.output
    glb_path = output_base + ".glb"

    if not metal_simplify_supported():
        # Stay under the target with margin: to_glb's cleanup fill_holes can
        # add faces, and any simplify invocation would hit the missing kernel.
        pre_target = int(target * 0.9)
        if int(faces.shape[0]) > pre_target:
            import fast_simplification
            log(f"  Simplifying mesh: {int(faces.shape[0]):,} -> ~{pre_target:,} faces (CPU; Metal simplify unsupported on this GPU)")
            verts_np = vertices.cpu().numpy().astype(np.float32)
            faces_np = faces.cpu().numpy().astype(np.int64)
            verts_np, faces_np = fast_simplification.simplify(
                verts_np, faces_np, 1.0 - pre_target / len(faces_np))
            vertices = torch.from_numpy(np.ascontiguousarray(verts_np, dtype=np.float32))
            faces = torch.from_numpy(np.ascontiguousarray(faces_np.astype(np.int32)))

    metal_error = None
    try:
        log("Baking PBR textures via Metal...")
        glb = o_voxel.postprocess.to_glb(
            vertices=vertices,
            faces=faces,
            attr_volume=attrs,
            coords=coords,
            attr_layout=layout,
            voxel_size=voxel_size,
            aabb=[[-0.5, -0.5, -0.5], [0.5, 0.5, 0.5]],
            decimation_target=target,
            texture_size=args.texture_size,
            verbose=True,
        )
        glb.export(glb_path)
        log(f"Saved: {glb_path}")
    except RuntimeError as error:
        metal_error = f"{error}"
        # Fall back outside the handler: the traceback pins the failed
        # attempt's MPS mesh/BVH buffers until the exception is released.

    if metal_error is not None:
        log(f"Metal bake failed: {metal_error}")
        gc.collect()
        if torch.backends.mps.is_available():
            torch.mps.empty_cache()
        log("Falling back to KDTree texture baker...")
        kdtree_bake(to_numpy(vertices, np.float32), to_numpy(faces),
                    to_numpy(coords, np.float32), to_numpy(attrs, np.float32),
                    origin, voxel_size, output_base, args.texture_size)

    log(f"Total time: {time.time() - t0:.1f}s generation + baking")


if __name__ == "__main__":
    main()
