"""MV-Adapter texture stage for TripoSG on Apple Silicon (MPS, no CUDA).

Given an untextured GLB and the prepared RGB image, generate a geometry-conditioned
6-view multi-view image set with MV-Adapter, then bake it onto the mesh's UVs with
the moderngl reimplementation of nvdiffrast's rasterize/interpolate/texture. Two
quality tiers, picked by installed RAM (or forced): SDXL at 768 for 32 GB+ Macs,
SD 2.1 at 512 for 16 GB Macs.

The `mvadapter` package and the two `inference_ig2mv_*` entry scripts are bundled
in the engine pack (or found via THREEDMATE_MVADAPTER_REPO on a dev machine). All
weights are resolved offline from the local HF cache; nothing leaves the device.

Design notes earned the hard way (see CLAUDE.md model-appearance casebook):
  - NO diffusers attention slicing: it overrides MV-Adapter's decoupled multi-view
    attention processor and desyncs the views into unrelated images.
  - The moderngl rasterizer must NOT vertically flip its framebuffer read: both
    nvdiffrast and moderngl are bottom-row-first, and the bake's grid_sample over
    uv_pos_ndc depends on that convention. A flip bakes an all-black texture.
"""
import os
import sys

# tier -> (entry script module, base model, fp16-fix VAE or None, render resolution)
_TIERS = {
    "sdxl": ("inference_ig2mv_sdxl", "stabilityai/stable-diffusion-xl-base-1.0",
             "madebyollin/sdxl-vae-fp16-fix", 768),
    "sd21": ("inference_ig2mv_sd", "LanguageMachines/stable-diffusion-2-1-base",
             None, 512),
}
# SDXL 6-view at 768 swaps ~10 GB on a 32 GB Mac; gate it to Macs with real
# headroom. Below the line, the lighter (faster, crisper) SD 2.1 / 512 tier runs.
# The app normally passes an explicit tier; this is the fallback for tier="auto".
_SDXL_MIN_RAM_GB = 48


def choose_tier(explicit: str) -> str:
    """Resolve 'auto' to a tier from physical RAM; pass 'sdxl'/'sd21' through."""
    if explicit in _TIERS:
        return explicit
    try:
        gb = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / (1024 ** 3)
    except (ValueError, OSError):
        gb = 16.0
    return "sdxl" if gb >= _SDXL_MIN_RAM_GB else "sd21"


def _ensure_scripts_on_path():
    """The MV-Adapter entry scripts live beside the package; make them importable."""
    repo = os.environ.get("THREEDMATE_MVADAPTER_REPO", "")
    if repo:
        for p in (repo, os.path.join(repo, "scripts")):
            if p and p not in sys.path:
                sys.path.insert(0, p)
        return
    # in the pack, texture_stage.py sits next to a bundled `mvadapter_scripts/` dir
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, "mvadapter_scripts"), here):
        if os.path.isdir(cand) and cand not in sys.path:
            sys.path.insert(0, cand)


def run_texture(emit, glb_path, image_path, out_path, tier="auto",
                steps=25, seed=42, guidance=3.0, uv_size=2048, num_views=6):
    """Texture `glb_path` from `image_path`, writing a textured GLB to `out_path`.

    `emit` is the runner's JSONL emitter. Returns the written path. Raises on
    failure so the caller can emit a recoverable error and still ship geometry.
    """
    os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    _ensure_scripts_on_path()

    import torch
    from mvadapter.pipelines.pipeline_texture import TexturePipeline, ModProcessConfig
    from mvadapter.utils import make_image_grid

    t = choose_tier(tier)
    script, base, vae, res = _TIERS[t]
    device = "mps" if torch.backends.mps.is_available() else "cpu"
    entry = __import__(script, fromlist=["prepare_pipeline", "run_pipeline"])

    emit({"type": "progress", "stage": "baking_textures", "percent": 82,
          "message": f"Loading texture model ({t.upper()})…"})
    pipe = entry.prepare_pipeline(
        base_model=base, vae_model=vae, unet_model=None, lora_model=None,
        adapter_path="huanngzh/mv-adapter", scheduler=None,
        num_views=num_views, device=device, dtype=torch.float16,
    )
    try:
        pipe.enable_vae_slicing()  # VAE-only; safe (unlike attention slicing)
    except Exception:  # noqa: BLE001
        pass

    emit({"type": "progress", "stage": "baking_textures", "percent": 88,
          "message": "Painting views…"})
    work_dir = os.path.dirname(os.path.abspath(out_path))
    mv_path = os.path.join(work_dir, "texture_views.png")
    images, _, _, _ = entry.run_pipeline(
        pipe, mesh_path=glb_path, num_views=num_views, text="high quality",
        image=image_path, height=res, width=res, num_inference_steps=steps,
        guidance_scale=guidance, seed=seed, reference_conditioning_scale=1.0,
        negative_prompt="watermark, ugly, deformed, noisy, blurry, low contrast",
        device=device, remove_bg_fn=None,
    )
    make_image_grid(images, rows=1).save(mv_path)

    emit({"type": "progress", "stage": "baking_textures", "percent": 95,
          "message": "Baking texture…"})
    tex = TexturePipeline(upscaler_ckpt_path=None, inpaint_ckpt_path=None, device=device)
    out = tex(
        mesh_path=glb_path, save_dir=work_dir, save_name="textured",
        uv_unwarp=True, preprocess_mesh=True, uv_size=uv_size, rgb_path=mv_path,
        rgb_process_config=ModProcessConfig(view_upscale=False, inpaint_mode="uv"),
        camera_azimuth_deg=[x - 90 for x in [0, 90, 180, 270, 180, 180]],
    )
    produced = out.shaded_model_save_path
    if produced != out_path:
        os.replace(produced, out_path)
    return out_path
