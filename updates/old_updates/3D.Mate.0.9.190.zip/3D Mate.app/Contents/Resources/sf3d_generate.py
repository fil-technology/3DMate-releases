#!/usr/bin/env python3
"""3D Mate Stable Fast 3D (SF3D) runner. Emits the same JSONL protocol as the
other engines (job_started / stage_started / progress / artifact / job_finished
/ error) so the app consumes it identically. Produces a UV-unwrapped, textured
GLB, running on MPS (or CPU) via the SF3D repo pointed at by THREEDMATE_SF3D_REPO
/ THREEDMATE_SF3D_PYTHON (dev). A bundled SF3D engine pack for customers is a
follow-up."""
import argparse
import json
import os
import sys
import time
import warnings

# Quiet library deprecation noise (e.g. timm.models.layers) from the logs; keep
# informative warnings like the MPS CPU-fallback notice.
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)


def emit(obj):
    print(json.dumps(obj), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--image", required=True)
    p.add_argument("--output", default="")
    p.add_argument("--job-id", default="sf3d")
    p.add_argument("--seed", default="0")
    p.add_argument("--texture-resolution", type=int, default=1024)
    args, _ = p.parse_known_args()

    start = time.time()
    emit({"type": "job_started", "job_id": args.job_id})

    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})
    if not os.path.exists(args.image):
        emit({"type": "error", "message": "Input image not found.", "recoverable": False})
        return 1

    repo = os.environ.get("THREEDMATE_SF3D_REPO", "/Volumes/3DMate-Dev/BackendCandidates/stable-fast-3d")
    if repo and repo not in sys.path:
        sys.path.insert(0, repo)
    # The gated weights are already cached (dev) or bundled (engine pack), so
    # load from cache without a network round-trip that would need a token.
    os.environ.setdefault("HF_HUB_OFFLINE", "1")

    try:
        import torch
        from PIL import Image
        from sf3d.system import SF3D
        from sf3d.utils import resize_foreground
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Stable Fast 3D runtime not available: {exc}", "recoverable": False})
        return 1

    device = "mps" if torch.backends.mps.is_available() else "cpu"

    emit({"type": "stage_started", "stage": "preparing_image", "message": "Preparing image"})
    # The app already hands us a background-removed cutout (prepared.png with
    # alpha), so skip SF3D's own rembg and just fit the foreground.
    image = resize_foreground(Image.open(args.image).convert("RGBA"), 0.85)

    emit({"type": "stage_started", "stage": "loading_model", "message": "Loading Stable Fast 3D"})
    model = SF3D.from_pretrained(
        "stabilityai/stable-fast-3d",
        config_name="config.yaml",
        weight_name="model.safetensors",
    )
    model.to(device)
    model.eval()

    emit({"type": "progress", "stage": "generating_mesh", "percent": 45, "message": "Generating mesh…"})
    emit({"type": "stage_started", "stage": "baking_textures", "message": "Baking texture"})
    with torch.no_grad():
        # remesh "none" / vertex_count -1: keep SF3D's native mesh; the app's
        # output modes handle any decimation afterwards.
        mesh, _glob = model.run_image(
            [image],
            bake_resolution=args.texture_resolution,
            remesh="none",
            vertex_count=-1,
        )

    emit({"type": "stage_started", "stage": "exporting_glb", "message": "Exporting model"})
    job_folder = os.path.dirname(os.path.abspath(args.image))
    out_glb = os.path.join(job_folder, "output.glb")
    mesh.export(out_glb, include_normals=True)
    emit({"type": "artifact", "kind": "glb", "path": out_glb})

    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})
    return 0


if __name__ == "__main__":
    sys.exit(main())
