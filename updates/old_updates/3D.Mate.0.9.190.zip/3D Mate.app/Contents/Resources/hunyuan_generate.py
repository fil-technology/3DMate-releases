#!/usr/bin/env python3
"""3D Mate Hunyuan3D runner. Wraps the Hunyuan3D-MLX unified CLI (`main.py full`)
and translates its stdout into the JSONL protocol the app consumes
(job_started / stage_started / progress / artifact / job_finished / error), so the
app treats it exactly like the TRELLIS wrapper and TripoSR runner.

The shape stage runs through hy3dgen on MPS; the paint (texture) stage runs on
MPS or MLX. The Hunyuan3D-MLX repo and its own Python 3.14 venv are pointed at
by THREEDMATE_HUNYUAN_REPO / THREEDMATE_HUNYUAN_PYTHON (dev). A bundled Hunyuan
engine pack for customers is a follow-up.

Cancellation: the app's EngineProcessController signals the whole process tree,
so the `main.py` child is reached directly; the SIGTERM handler below is defense
in depth for the case where only this runner is signaled."""
import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import time

_child = None


def emit(obj):
    print(json.dumps(obj), flush=True)


def _forward_term(signum, _frame):
    if _child and _child.poll() is None:
        try:
            _child.terminate()
        except Exception:  # noqa: BLE001
            pass
    sys.exit(143)


def main():
    global _child
    p = argparse.ArgumentParser()
    p.add_argument("--image", required=True)
    p.add_argument("--output", default="")          # parent of job folders (unused; we write into the job)
    p.add_argument("--job-id", default="hunyuan")
    p.add_argument("--seed", default="0")
    p.add_argument("--shape-preset", default="2.1")
    p.add_argument("--paint-preset", default="2.1")
    p.add_argument("--view", action="append", default=[])
    # 1 = shape + texture (needs ~48 GB); 0 = geometry only (fits 32 GB). The
    # app sets this from the Mac's memory so texture only runs where it fits.
    p.add_argument("--texture", default="1")
    args, _ = p.parse_known_args()

    signal.signal(signal.SIGTERM, _forward_term)
    signal.signal(signal.SIGINT, _forward_term)

    start = time.time()
    emit({"type": "job_started", "job_id": args.job_id})

    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})
    if not os.path.exists(args.image):
        emit({"type": "error", "message": "Input image not found.", "recoverable": False})
        return 1

    repo = os.environ.get("THREEDMATE_HUNYUAN_REPO", "/Volumes/3DMate-Dev/BackendCandidates/hunyuan3d-mlx")
    python = os.environ.get("THREEDMATE_HUNYUAN_PYTHON", os.path.join(repo, ".venv/bin/python3"))
    main_py = os.path.join(repo, "main.py")
    if not os.path.exists(main_py) or not os.path.exists(python):
        emit({"type": "error", "message": "The Hunyuan3D engine isn't set up on this Mac yet.", "recoverable": False})
        return 1

    job_folder = os.path.dirname(os.path.abspath(args.image))
    out_dir = os.path.join(job_folder, "hy_out")
    os.makedirs(out_dir, exist_ok=True)

    want_texture = args.texture == "1"
    # `--seed` is a top-level arg on main.py and must precede the subcommand.
    subcommand = "full" if want_texture else "shape"
    cmd = [python, main_py, "--seed", str(args.seed), subcommand,
           "--image", os.path.abspath(args.image)]
    for view in args.view:
        if os.path.exists(view):
            cmd += ["--image", os.path.abspath(view)]
    if want_texture:
        cmd += ["--output-dir", out_dir,
                "--shape-preset", args.shape_preset,
                "--paint-preset", args.paint_preset]
    else:
        # Geometry only: skip the memory-heavy paint stage entirely.
        cmd += ["--output", os.path.join(out_dir, "shape.glb"),
                "--shape-preset", args.shape_preset]
    cmd += ["--no-shape-safetensors"]

    env = dict(os.environ)
    env.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

    emit({"type": "stage_started", "stage": "loading_model", "message": "Loading Hunyuan3D"})

    _child = subprocess.Popen(cmd, cwd=repo, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True, bufsize=1, env=env)

    shape_started = shape_done = paint_started = False
    for raw in _child.stdout:
        line = raw.rstrip()
        if not line:
            continue
        # Translate the CLI's own markers into pipeline stages.
        if not shape_started and ("Loading model from" in line or line.startswith("shape_device=")):
            emit({"type": "stage_started", "stage": "generating_structure", "message": "Generating shape"})
            shape_started = True
        elif line.startswith("shape_time="):
            emit({"type": "progress", "stage": "generating_mesh", "percent": 55, "message": "Shape ready"})
            shape_done = True
        elif shape_done and not paint_started and ("Loading model from" in line or line.startswith("paint_model=")):
            emit({"type": "stage_started", "stage": "baking_textures", "message": "Painting texture"})
            paint_started = True
        elif line.startswith("paint_time="):
            emit({"type": "progress", "stage": "baking_textures", "percent": 92, "message": "Texture ready"})
        # Forward a compact log line for the activity feed.
        emit({"type": "log", "message": line[:200]})

    rc = _child.wait()

    paint_glb = os.path.join(out_dir, "paint.glb")
    shape_glb = os.path.join(out_dir, "shape.glb")
    src = paint_glb if os.path.exists(paint_glb) else (shape_glb if os.path.exists(shape_glb) else None)
    if rc != 0 or src is None:
        emit({"type": "error", "message": f"Hunyuan3D generation failed (exit {rc}).", "recoverable": False})
        return 1

    emit({"type": "stage_started", "stage": "exporting_glb", "message": "Exporting model"})
    out_glb = os.path.join(job_folder, "output.glb")
    shutil.copyfile(src, out_glb)
    emit({"type": "artifact", "kind": "glb", "path": out_glb})

    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})
    return 0


if __name__ == "__main__":
    sys.exit(main())
