// The interactive Three.js viewer for the QuickLook preview. Three.js and the
// loaders are loaded as sibling <script> tags ahead of this file. The scene is
// built at load; the extension then calls window.load3DMate(base64, ext) once
// the WKWebView has finished loading, so the model bytes are injected rather
// than inlined into a multi-megabyte page.
(function () {
  "use strict";
  var container = document.getElementById("stage");

  var scene = new THREE.Scene();
  scene.background = new THREE.Color(0x111114);

  var camera = new THREE.PerspectiveCamera(38, window.innerWidth / window.innerHeight, 0.01, 5000);

  var renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
  renderer.setPixelRatio(window.devicePixelRatio || 1);
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputEncoding = THREE.sRGBEncoding;
  container.appendChild(renderer.domElement);

  // A hemisphere fill plus three directionals (key, side fill, and a back rim),
  // so an untextured model reads all the way around instead of going pure black
  // on the side away from the key. Nothing fetched from the network.
  scene.add(new THREE.HemisphereLight(0xffffff, 0x3a3a44, 0.9));
  var key = new THREE.DirectionalLight(0xffffff, 1.7); key.position.set(-0.6, 1.0, 0.8); scene.add(key);
  var fill = new THREE.DirectionalLight(0xdfe9ff, 0.8); fill.position.set(0.8, 0.2, -0.4); scene.add(fill);
  var back = new THREE.DirectionalLight(0xffffff, 0.6); back.position.set(0.3, 0.5, -1.0); scene.add(back);

  var controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.autoRotate = true;
  controls.autoRotateSpeed = 1.1;
  // A drag stops the auto-spin, so a look-around does not fight the animation.
  controls.addEventListener("start", function () { controls.autoRotate = false; });
  camera.position.set(0, 0, 3);
  controls.update();

  function frame(object) {
    var box = new THREE.Box3().setFromObject(object);
    var size = box.getSize(new THREE.Vector3());
    var center = box.getCenter(new THREE.Vector3());
    object.position.sub(center); // re-center at origin

    var radius = Math.max(size.x, size.y, size.z) * 0.5 || 1;
    controls.target.set(0, 0, 0);
    var dist = radius / Math.sin((camera.fov * Math.PI / 180) / 2) * 1.25;
    camera.position.set(radius * 0.5, radius * 0.35, dist);
    camera.near = dist / 100;
    camera.far = dist * 100;
    camera.updateProjectionMatrix();
    controls.update();
    scene.add(object);
  }

  function fail(msg) {
    var el = document.getElementById("msg");
    el.textContent = msg || "This model could not be displayed.";
    el.style.display = "flex";
  }

  function base64ToArrayBuffer(b64) {
    var binary = atob(b64);
    var len = binary.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
    return bytes.buffer;
  }

  function normalizeMaterials(root) {
    root.traverse(function (n) {
      if (n.isMesh) {
        if (n.geometry && n.geometry.computeVertexNormals && !n.geometry.attributes.normal) n.geometry.computeVertexNormals();
        var mats = Array.isArray(n.material) ? n.material : [n.material];
        mats.forEach(function (m) { if (m) { m.side = THREE.DoubleSide; } });
        if (!n.material || (Array.isArray(n.material) && n.material.length === 0)) {
          n.material = new THREE.MeshStandardMaterial({ color: 0xbfc4cc, metalness: 0.1, roughness: 0.7 });
        }
      }
    });
  }

  // Called by the extension after the page loads, with the model as base64 and
  // its extension (glb, gltf, obj, stl, ply).
  window.load3DMate = function (b64, ext) {
    try {
      var buffer = base64ToArrayBuffer(b64);
      ext = (ext || "").toLowerCase();

      if (ext === "glb" || ext === "gltf") {
        new THREE.GLTFLoader().parse(buffer, "", function (gltf) {
          frame(gltf.scene);
        }, function () { fail(); });
      } else if (ext === "obj") {
        var text = new TextDecoder("utf-8").decode(buffer);
        var obj = new THREE.OBJLoader().parse(text);
        normalizeMaterials(obj); frame(obj);
      } else if (ext === "stl") {
        var geo = new THREE.STLLoader().parse(buffer);
        geo.computeVertexNormals();
        frame(new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0xbfc4cc, metalness: 0.1, roughness: 0.7 })));
      } else if (ext === "ply") {
        var pgeo = new THREE.PLYLoader().parse(buffer);
        pgeo.computeVertexNormals();
        var hasColor = !!pgeo.attributes.color;
        frame(new THREE.Mesh(pgeo, new THREE.MeshStandardMaterial({
          color: hasColor ? 0xffffff : 0xbfc4cc, vertexColors: hasColor, metalness: 0.05, roughness: 0.75
        })));
      } else {
        fail("Unsupported format.");
      }
    } catch (e) {
      fail(String(e));
    }
  };

  function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
  }
  animate();

  window.addEventListener("resize", function () {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
})();
