#!/usr/bin/env python3
"""3D Mate Step1X-3D runner. Emits the same JSONL protocol as the other engines
(job_started / stage_started / progress / artifact / job_finished / error) so the
app consumes it identically.

Step1X-3D produces high-fidelity, watertight GEOMETRY (untextured here; the
texture module is CUDA-bound and not shipped). It runs on Apple Silicon via MPS:
attention defaults to torch SDPA, surface extraction is CPU skimage marching
cubes, and there are no CUDA-only ops on the geometry path. The label model adds
sharp-edge and symmetry control, which is what we want for crisp printable shapes.

The step1x3d_geometry package is imported from the installed engine pack
(site-packages) or, on a dev machine, from THREEDMATE_STEP1X_REPO. That tree must
carry the Apple-Silicon spike patches (Backend/patches/step1x3d-mps-spike.patch):
import only `models` (skip training-only deps), an MPS/CPU get_device fallback,
and a numpy-2-compatible trimesh."""
import argparse
import json
import os
import sys
import time
import traceback

# Unsupported MPS ops fall back to CPU instead of crashing the run.
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")


def emit(obj):
    print(json.dumps(obj), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--image", required=True)
    p.add_argument("--output", default="")
    p.add_argument("--job-id", default="step1x")
    p.add_argument("--model-folder", default="")
    p.add_argument("--seed", default="0")
    p.add_argument("--steps", type=int, default=50)
    p.add_argument("--guidance", type=float, default=7.5)
    p.add_argument("--octree", type=int, default=384, help="octree resolution; higher = finer detail, more memory")
    p.add_argument("--faces", type=int, default=400000, help="max output faces")
    p.add_argument("--edge-type", default="sharp", choices=["sharp", "normal"],
                   help="label geometry_type class (sharp biases toward crisp edges)")
    p.add_argument("--symmetry", default="x", choices=["x", "asymmetry"])
    p.add_argument("--base", action="store_true",
                   help="use the base 1300m model (518px conditioning, often sharper) instead of the label model")
    p.add_argument("--fp32-decode", action="store_true",
                   help="decode the VAE field in float32 for maximum surface sharpness")
    args, _ = p.parse_known_args()
    # The label model adds symmetry/sharp control at 224px conditioning; the base
    # model conditions at 518px, which transfers finer detail. Default to label.
    use_label = not args.base
    if args.fp32_decode:
        os.environ["STEP1X_DECODE_FP32"] = "1"
        os.environ.setdefault("PYTORCH_MPS_HIGH_WATERMARK_RATIO", "0.0")

    start = time.time()
    emit({"type": "job_started", "job_id": args.job_id})

    # Prefer the installed pack (step1x3d_geometry already on the path); on a dev
    # machine fall back to the fork repo. Weights are self-contained; stay offline.
    repo = os.environ.get("THREEDMATE_STEP1X_REPO", "")
    if repo and repo not in sys.path:
        sys.path.insert(0, repo)
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    # Point Hugging Face at the bundle's own cache. The geometry pipeline
    # instantiates DINOv2-with-registers from a config it resolves by repo id
    # (facebook/dinov2-with-registers-large); without HF_HOME, transformers looks
    # in ~/.cache/huggingface, which is empty on a customer machine, and the
    # offline load dies with "couldn't connect ... not a directory containing
    # config.json". The config ships in <model-folder>/hfcache, so aim there.
    # (Other engines set this already; Step1X was missing it.)
    if args.model_folder:
        _hf = os.path.join(args.model_folder, "hfcache")
        if os.path.isdir(_hf):
            os.environ["HF_HOME"] = _hf

    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})
    if not os.path.exists(args.image):
        emit({"type": "error", "message": "Input image not found.", "recoverable": False})
        return 1

    try:
        import torch
        # Pre-load the marching-cubes module now, off the hot path (see the
        # TripoSG runner for why: a lazy skimage import mid-run on a busy or
        # removable volume can be interrupted and leave no mesh).
        import skimage.measure  # noqa: F401
        from step1x3d_geometry.models.pipelines.pipeline import Step1X3DGeometryPipeline
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Step1X-3D runtime not available: {exc}", "recoverable": False})
        return 1

    device = "mps" if torch.backends.mps.is_available() else "cpu"

    emit({"type": "stage_started", "stage": "loading_model", "message": "Loading Step1X-3D"})
    subfolder = "Step1X-3D-Geometry-Label-1300m" if use_label else "Step1X-3D-Geometry-1300m"
    local = args.model_folder
    model_src = local if (local and os.path.isdir(local)) else "stepfun-ai/Step1X-3D"
    try:
        pipe = Step1X3DGeometryPipeline.from_pretrained(model_src, subfolder=subfolder).to(device)
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Could not load Step1X-3D weights: {exc}", "recoverable": False})
        return 1

    try:
        seed = int(args.seed)
    except (TypeError, ValueError):
        seed = 0

    emit({"type": "stage_started", "stage": "generating_structure", "message": "Generating shape"})
    emit({"type": "progress", "stage": "generating_structure", "percent": 30, "message": "Generating shape…"})
    kwargs = dict(guidance_scale=args.guidance, num_inference_steps=args.steps,
                  octree_resolution=args.octree, max_facenum=args.faces,
                  generator=torch.Generator(device=pipe.device).manual_seed(seed),
                  force_remove_background=False,
                  # Keep the largest body and drop stray/degenerate faces: the
                  # latter default False upstream and leaves sliver triangles that
                  # span the mesh (visible as diagonal lines in a render).
                  do_remove_floater=True, do_remove_degenerate_face=True)
    if use_label:
        # NOTE: the encoder reads `geometry_type` (a LIST), not `edge_type`; the
        # shipped inference.py example passes edge_type, which is silently a no-op.
        kwargs["label"] = {"symmetry": args.symmetry, "geometry_type": [args.edge_type]}
    try:
        out = pipe(args.image, **kwargs)
    except Exception as exc:  # noqa: BLE001
        emit({"type": "log", "level": "error", "message": "[traceback]\n" + traceback.format_exc()})
        detail = str(exc)
        low_memory = isinstance(exc, MemoryError) or any(
            m in detail for m in ("NoneType", "Interrupted system call", "Cannot allocate", "out of memory"))
        if low_memory:
            emit({"type": "error", "recoverable": True, "message":
                  "Ran low on memory while building the mesh. Close other apps "
                  "(Google Drive especially), then try again, or lower the detail."})
        else:
            emit({"type": "error", "recoverable": False, "message": f"Mesh generation failed: {detail}"})
        return 1

    mesh = out.mesh[0] if hasattr(out, "mesh") else out
    if mesh is None or not hasattr(mesh, "vertices") or len(mesh.vertices) == 0:
        emit({"type": "error", "recoverable": True, "message":
              "The mesh step produced no geometry, usually a sign the machine ran low on memory."})
        return 1

    emit({"type": "stage_started", "stage": "generating_mesh", "message": "Building mesh"})
    emit({"type": "progress", "stage": "generating_mesh", "percent": 85, "message": "Finishing mesh…"})

    # Keep outward-facing normals (positive signed volume; see the inside-out
    # casebook). Harmless when already correct.
    try:
        if mesh.volume < 0:
            mesh.invert()
    except Exception:  # noqa: BLE001
        pass

    job_folder = os.path.dirname(os.path.abspath(args.image))
    out_glb = os.path.join(job_folder, "output.glb")
    mesh.export(out_glb)
    emit({"type": "artifact", "kind": "glb", "path": out_glb})

    # STL beside the GLB for printing, exactly like the other engines.
    out_stl = os.path.join(job_folder, "output.stl")
    try:
        mesh.export(out_stl)
        emit({"type": "artifact", "kind": "stl", "path": out_stl})
    except Exception as exc:  # noqa: BLE001
        emit({"type": "log", "level": "warning", "message": f"STL export failed: {exc}"})

    emit({"type": "stage_started", "stage": "exporting_glb", "message": "Finishing"})
    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})
    return 0


if __name__ == "__main__":
    sys.exit(main())
