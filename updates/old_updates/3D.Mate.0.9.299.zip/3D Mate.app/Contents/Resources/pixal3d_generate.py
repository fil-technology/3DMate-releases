#!/usr/bin/env python3
"""3D Mate Pixal3D runner. Emits the same JSONL protocol as the other engines
(job_started / stage_started / progress / artifact / job_finished / error).

Pixal3D (TencentARC, MIT) is a TRELLIS-v1-family, pixel-back-projection image-to-3D
model. Pipeline: MoGe-2 gives the camera FOV, DINOv3 features are projected onto the
voxel grid ("proj" conditioning), and a sparse flow stack (structure flow + SLat shape
flow + FlexiDualGrid decoder), ported to Apple MLX, samples the geometry; the dual-grid
mesh is extracted on CPU via o_voxel. A torch/MPS front-end (MoGe + DINOv3 + NAF, with a
memory-safe pure-torch neighborhood attention) runs first and is freed before the MLX
core. No CUDA. Geometry only (texture + the res>=1024 cascade are not shipped).

BIG-MACHINE MODEL: the res-512 shape decode and 512x512 NAF are memory-heavy (Pixal3D's
own default targets ~192 GB). This should be RAM-gated in the app like TRELLIS.2 Ultra.

The MLX core (mlx_backend) comes from THREEDMATE_PIXAL3D_REPO (the trellis2-apple fork)
or the installed pack's site-packages; the DINOv3 projection extractor from the pixal3d
package (THREEDMATE_PIXAL3D_PKG); mesh extraction from o_voxel. Weights + hub repos load
offline from --model-folder (torchhub/ + hfcache/ + ckpts/)."""
import argparse
import json
import os
import sys
import time
import traceback

os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
os.environ.setdefault("ATTN_BACKEND", "sdpa")
os.environ.setdefault("SPCONV_ALGO", "native")


def emit(obj):
    print(json.dumps(obj), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--image", required=True)
    p.add_argument("--output", default="")
    p.add_argument("--job-id", default="pixal3d")
    p.add_argument("--model-folder", default="")
    p.add_argument("--seed", default="42")
    p.add_argument("--shape-res", type=int, default=512, help="shape decode resolution (512; higher needs big memory)")
    args, _ = p.parse_known_args()

    start = time.time()
    emit({"type": "job_started", "job_id": args.job_id})

    repo = os.environ.get("THREEDMATE_PIXAL3D_REPO", "")
    if repo and repo not in sys.path:
        sys.path.insert(0, repo)
    pkg = os.environ.get("THREEDMATE_PIXAL3D_PKG", "")
    if pkg and pkg not in sys.path:
        sys.path.insert(0, pkg)
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})
    if not os.path.exists(args.image):
        emit({"type": "error", "message": "Input image not found.", "recoverable": False})
        return 1

    mf = args.model_folder
    ckpt_dir = os.environ.get("THREEDMATE_PIXAL3D_CKPTS", "")
    if mf and os.path.isdir(mf):
        os.environ["TORCH_HOME"] = os.path.join(mf, "torchhub")
        os.environ["HF_HOME"] = os.path.join(mf, "hfcache")
        if not ckpt_dir:
            ckpt_dir = os.path.join(mf, "ckpts")
    if not ckpt_dir:
        emit({"type": "error", "message": "Pixal3D weights folder not found.", "recoverable": False})
        return 1

    try:
        import torch  # noqa: F401
        from mlx_backend.pixal3d_pipeline import Pixal3DPipeline
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Pixal3D runtime not available: {exc}", "recoverable": False})
        return 1

    try:
        seed = int(args.seed)
    except (TypeError, ValueError):
        seed = 42

    emit({"type": "stage_started", "stage": "loading_model", "message": "Loading Pixal3D"})

    _STAGE = {"load": "loading_model", "normal": "generating_structure",
              "structure": "generating_structure", "latent": "generating_mesh",
              "mesh": "generating_mesh"}
    _PCT = {"load": 10, "normal": 15, "structure": 40, "latent": 70, "mesh": 92}

    def progress(stage, message, frac=None):
        emit({"type": "progress", "stage": _STAGE.get(stage, "generating_structure"),
              "percent": _PCT.get(stage, 50), "message": message + "…"})

    job_folder = os.path.dirname(os.path.abspath(args.image))
    try:
        pipe = Pixal3DPipeline(ckpt_dir, device=("mps" if _mps() else "cpu"))
        emit({"type": "stage_started", "stage": "generating_structure", "message": "Estimating camera"})
        mesh = pipe.run(args.image, out_dir=job_folder, seed=seed,
                        shape_res=args.shape_res, progress=progress)
    except Exception as exc:  # noqa: BLE001
        # Persist the full traceback as a log line. The app writes every event to
        # the job's events.jsonl and logs.txt, so this puts the real Python cause
        # (which frame, which repo/file) into a shared job folder. Some errors, like
        # the Hugging Face "cannot locate file" one, carry a generic message that
        # never names the missing file. The traceback frames do.
        emit({"type": "log", "level": "error", "message": "[traceback]\n" + traceback.format_exc()})
        detail = str(exc)
        low_memory = isinstance(exc, MemoryError) or any(
            m in detail for m in ("NoneType", "Interrupted system call", "Cannot allocate",
                                   "out of memory", "Invalid buffer size"))
        if low_memory:
            emit({"type": "error", "recoverable": True, "message":
                  "Ran low on memory building the mesh. Pixal3D needs a large-memory Mac; "
                  "close other apps and try again, or use a lighter engine."})
        else:
            emit({"type": "error", "recoverable": False, "message": f"Mesh generation failed: {detail}"})
        return 1

    if mesh is None or len(mesh.vertices) == 0:
        emit({"type": "error", "recoverable": True, "message":
              "The mesh step produced no geometry, usually a sign the machine ran low on memory."})
        return 1
    try:
        if mesh.volume < 0:
            mesh.invert()
    except Exception:  # noqa: BLE001
        pass

    emit({"type": "stage_started", "stage": "generating_mesh", "message": "Building mesh"})
    out_glb = os.path.join(job_folder, "output.glb")
    mesh.export(out_glb)
    emit({"type": "artifact", "kind": "glb", "path": out_glb})
    out_stl = os.path.join(job_folder, "output.stl")
    try:
        mesh.export(out_stl)
        emit({"type": "artifact", "kind": "stl", "path": out_stl})
    except Exception as exc:  # noqa: BLE001
        emit({"type": "log", "level": "warning", "message": f"STL export failed: {exc}"})

    emit({"type": "stage_started", "stage": "exporting_glb", "message": "Finishing"})
    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})
    return 0


def _mps():
    try:
        import torch
        return torch.backends.mps.is_available()
    except Exception:  # noqa: BLE001
        return False


if __name__ == "__main__":
    sys.exit(main())
