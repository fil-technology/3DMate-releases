#!/usr/bin/env python3
"""3D Mate Stable Point-Aware 3D (SPAR3D) runner. Emits the same JSONL protocol as
the other engines (job_started / stage_started / progress / artifact / job_finished
/ error) so the app consumes it identically.

SPAR3D produces a UV-unwrapped, textured GLB PLUS an editable point cloud
(points.ply). It runs on torch/MPS (needs macOS 15.2) from the installed engine
pack (site-packages) or, on a dev machine, from THREEDMATE_SPAR3D_REPO.

Weights load fully offline: the main model from the explicit --model-folder
(Models/SPAR3D: config.yaml + model.safetensors), the DINOv2-large image tokenizer
from the HF cache (shared with SF3D), and the OpenAI CLIP the material estimator
needs from --clip-folder via ALPHA_CLIP_PATH. Every cache is forced into the
workspace so NOTHING writes to the internal disk (the dev spike proved AlphaCLIP
and DINOv2 otherwise fall back to ~/.cache).

NOTE: the shipped spar3d pack has spar3d/utils.py patched so the
transparent_background import is lazy, so this runner never imports it (the app
already hands us a background-removed RGBA cutout)."""
import argparse
import json
import logging
import os
import sys
import time
import warnings

# Quiet library deprecation noise from the logs; keep informative warnings like
# the MPS CPU-fallback notice.
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)
# AlphaCLIP does `from pkg_resources import packaging`, which warns on modern
# setuptools. We pin setuptools<81 in the pack so it works; silence just this one
# line and keep other UserWarnings (the MPS CPU-fallback notice) visible.
warnings.filterwarnings("ignore", message=r".*pkg_resources is deprecated.*")


# SPAR3D logs two root-logger warnings at import when the optional remeshing
# backends (gpytoolbox, pynanoinstantmeshes) are absent. We run remesh="none" on
# purpose, so these are expected; drop just those lines from the console.
class _DropRemeshNotice(logging.Filter):
    def filter(self, record):  # noqa: A003
        return "remeshing functionality will be disabled" not in record.getMessage()


logging.getLogger().addFilter(_DropRemeshNotice())


def emit(obj):
    print(json.dumps(obj), flush=True)


def _install_live_preview(job_folder, stride=2):
    """Show the point cloud forming, like TRELLIS's live preview.

    SPAR3D samples its point cloud progressively: PointCloudSampler.
    sample_batch_progressive yields intermediate states as x["xstart"]. We wrap
    that generator to write the running cloud's xyz as raw little-endian float32
    triples (the format PointCloudPreview reads) and emit a `step_points`
    artifact every `stride` steps, which ProgressCard renders and spins live.
    Everything is wrapped in try/except: a preview hiccup must never sink a real
    generation, so on any error we just stop previewing and let sampling run."""
    try:
        from spar3d.models.diffusion.sampler import PointCloudSampler
        import numpy as np
    except Exception:  # noqa: BLE001
        return
    preview = os.path.join(job_folder, "points_preview.bin")
    original = PointCloudSampler.sample_batch_progressive
    counter = {"n": 0}

    def wrapped(self, *args, **kwargs):
        for step in original(self, *args, **kwargs):
            try:
                counter["n"] += 1
                xs = step.get("xstart") if isinstance(step, dict) else None
                if xs is not None and counter["n"] % stride == 0:
                    pc = xs[0].detach().float().cpu().numpy()   # [C, N]
                    xyz = np.ascontiguousarray(pc[:3].T)        # [N, 3] xyz
                    xyz = xyz - xyz.mean(axis=0)
                    scale = float(np.abs(xyz).max())
                    if scale > 1e-6:
                        xyz = xyz / scale
                    tmp = preview + ".tmp"
                    xyz.astype("<f4").tofile(tmp)
                    os.replace(tmp, preview)
                    emit({"type": "artifact", "kind": "step_points", "path": preview})
            except Exception:  # noqa: BLE001
                pass
            yield step

    PointCloudSampler.sample_batch_progressive = wrapped


def _pin_caches_to_workspace(args):
    """Force every model cache into the workspace, never the internal disk.

    The app already sets HF_HOME et al. in the child env, but a headless/dev
    invocation might not, and the spike proved AlphaCLIP + torch.hub download to
    ~/.cache otherwise. Only fill what is missing, and derive a base from the
    workspace (or the job folder) so nothing ever lands on the startup disk."""
    base = os.environ.get("THREEDMATE_WORKSPACE") or os.path.dirname(
        os.path.abspath(args.output or args.image)
    )
    cache_root = os.path.join(base, "HFCache")
    os.environ.setdefault("HF_HOME", cache_root)
    os.environ.setdefault("HUGGINGFACE_HUB_CACHE", os.path.join(cache_root, "hub"))
    os.environ.setdefault("TORCH_HOME", os.path.join(cache_root, "torch"))
    # torch.hub / AlphaCLIP and friends honour XDG_CACHE_HOME for their fallback
    # downloads; point it at the workspace too so nothing leaks to ~/.cache.
    os.environ.setdefault("XDG_CACHE_HOME", os.path.join(base, "cache"))
    # The weights are already present, so stay offline (no token, no network).
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--image", required=True)
    p.add_argument("--output", default="")
    p.add_argument("--job-id", default="spar3d")
    p.add_argument("--model-folder", default="", help="Models/SPAR3D (config.yaml + model.safetensors)")
    p.add_argument("--clip-folder", default="", help="dir holding ViT-L-14-336px.pt for the material estimator")
    p.add_argument("--seed", default="0")
    # 2048 bakes a 2K albedo atlas: sharper textures on the visible surfaces for
    # ~20s more than the reference 1024 default, and it stays within the model's
    # memory envelope (validated on this M1 Pro). The mesh detail is unchanged;
    # this only affects texture crispness.
    p.add_argument("--texture-resolution", type=int, default=2048)
    args, _ = p.parse_known_args()

    start = time.time()
    emit({"type": "job_started", "job_id": args.job_id})

    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})
    if not os.path.exists(args.image):
        emit({"type": "error", "message": "Input image not found.", "recoverable": False})
        return 1

    _pin_caches_to_workspace(args)
    # The material estimator reads its CLIP checkpoint from this dir (see the
    # ALPHA_CLIP_PATH env var). The app sets it too; set it here as a backstop so
    # a headless run never downloads it.
    if args.clip_folder:
        os.environ.setdefault("ALPHA_CLIP_PATH", args.clip_folder)

    # On a dev machine, add the fork repo to the path; with the pack, spar3d is
    # importable from site-packages so no repo path is needed.
    repo = os.environ.get("THREEDMATE_SPAR3D_REPO", "")
    if repo and repo not in sys.path:
        sys.path.insert(0, repo)

    try:
        import torch
        from PIL import Image
        from spar3d.system import SPAR3D
        # The pack ships spar3d/utils.py patched so importing these does NOT pull
        # in transparent_background (the app already removed the background).
        from spar3d.utils import foreground_crop, remove_background
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Stable Point-Aware 3D runtime not available: {exc}", "recoverable": False})
        return 1

    device = "mps" if torch.backends.mps.is_available() else "cpu"

    emit({"type": "stage_started", "stage": "loading_model", "message": "Loading Stable Point-Aware 3D"})
    model_folder = args.model_folder
    if not (model_folder and os.path.exists(os.path.join(model_folder, "model.safetensors"))):
        emit({"type": "error",
              "message": "Stable Point-Aware 3D weights not found. Reinstall the model in Settings.",
              "recoverable": False})
        return 1
    try:
        model = SPAR3D.from_pretrained(
            model_folder,
            config_name="config.yaml",
            weight_name="model.safetensors",
            low_vram_mode=True,
        )
        model.to(device)
        model.eval()
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Couldn't load Stable Point-Aware 3D: {exc}", "recoverable": False})
        return 1

    emit({"type": "stage_started", "stage": "preparing_image", "message": "Preparing image"})
    # The app hands us a background-removed RGBA cutout, so remove_background is a
    # no-op here; foreground_crop fits the object as SPAR3D expects.
    #
    # foreground_ratio MUST be 1.3 (SPAR3D's real default in run.py). An earlier
    # 0.85 (copied from the SF3D runner, whose help text also mislabels the value)
    # framed the object wrong for SPAR3D's conditioning and wrecked BOTH geometry
    # and texture: squashed meshes and washed-out, iridescent albedos on every
    # input. 1.3 restores clean, well-proportioned results (proven against the
    # reference on the Christ the Redeemer statue). Confirmed independent of
    # low_vram_mode, so that stays True (safe on 16 GB Macs).
    try:
        image = remove_background(Image.open(args.image).convert("RGBA"), None)
        image = foreground_crop(image, 1.3)
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Couldn't prepare the input image: {exc}", "recoverable": False})
        return 1

    job_folder = os.path.dirname(os.path.abspath(args.image))
    out_glb = os.path.join(job_folder, "output.glb")
    out_ply = os.path.join(job_folder, "points.ply")

    try:
        emit({"type": "stage_started", "stage": "generating_structure", "message": "Generating point cloud"})
        emit({"type": "progress", "stage": "generating_structure", "percent": 30, "message": "Generating point cloud…"})
        emit({"type": "stage_started", "stage": "generating_mesh", "message": "Building mesh"})
        emit({"type": "progress", "stage": "generating_mesh", "percent": 60, "message": "Building mesh…"})
        emit({"type": "stage_started", "stage": "baking_textures", "message": "Baking texture"})
        # Stream the point cloud as it denoises so the app shows a live preview
        # (SPAR3D only samples the cloud inside run_image, so hook it here).
        _install_live_preview(job_folder)
        with torch.no_grad():
            # remesh "none" / vertex_count -1: keep SPAR3D's native mesh; the
            # app's output modes handle any decimation afterwards. return_points
            # gives us the editable point cloud to export alongside the GLB.
            mesh, glob = model.run_image(
                [image],
                bake_resolution=args.texture_resolution,
                remesh="none",
                vertex_count=-1,
                return_points=True,
            )
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Generation failed: {exc}", "recoverable": False})
        return 1

    emit({"type": "stage_started", "stage": "exporting_glb", "message": "Exporting model"})
    try:
        mesh.export(out_glb, include_normals=True)
        emit({"type": "artifact", "kind": "glb", "path": out_glb})
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Couldn't export the model: {exc}", "recoverable": False})
        return 1

    # The point cloud is a bonus artifact: a failure here must not sink a good GLB.
    try:
        glob["point_clouds"][0].export(out_ply)
        emit({"type": "artifact", "kind": "ply", "path": out_ply})
    except Exception as exc:  # noqa: BLE001
        emit({"type": "log", "level": "warning",
              "message": f"Point cloud export failed (mesh still shipped): {exc}"})

    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})
    return 0


if __name__ == "__main__":
    sys.exit(main())
