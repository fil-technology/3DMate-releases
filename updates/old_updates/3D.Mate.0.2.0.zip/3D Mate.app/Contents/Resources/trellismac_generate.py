#!/usr/bin/env python3
"""3D Mate backend wrapper — JSONL progress protocol.

The Swift app (TrellisGenerationBackend) launches this script and parses one
JSON object per stdout line:

    {"type":"job_started","job_id":"..."}
    {"type":"stage_started","stage":"loading_model","message":"Loading model"}
    {"type":"progress","stage":"generating_structure","percent":35,"message":"..."}
    {"type":"artifact","kind":"glb","path":"/path/output.glb"}
    {"type":"job_finished","duration_seconds":320}
    {"type":"job_cancelled"}
    {"type":"error","message":"...","recoverable":true}

Modes:
  --mock   simulate the pipeline (no model needed) — used by the in-app mock
           backend tests and CI.
  (real)   dispatch to the trellis-mac backend (PyTorch MPS port of TRELLIS.2)
           set up by Scripts/setup_backend_phase1b.sh inside the external SSD
           workspace, translating its console output into JSONL stages.

All caches stay on the external SSD — the app exports HF_HOME/TMPDIR/etc.
before launching this script.
"""
import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid

STAGES = [
    ("validating_input", 0.3, "Validating input"),
    ("preparing_image", 0.4, "Preparing image"),
    ("loading_model", 1.0, "Loading model"),
    ("generating_structure", 2.0, "Generating structure"),
    ("generating_mesh", 1.5, "Generating mesh"),
    ("baking_textures", 1.2, "Baking textures"),
    ("exporting_glb", 0.4, "Exporting GLB"),
    ("exporting_usdz", 0.4, "Exporting USDZ"),
]

SPEED = {"fast": 0.5, "balanced": 1.0, "quality": 1.8}

# preset -> (pipeline type, texture size, bake face budget).
# 512² textures are far too sparse for ~200k-face meshes (≈1 texel/triangle,
# reads as speckle) — upstream's own default is 1024 even for the 512 pipeline.
# The face budget bounds xatlas UV-unwrap time, the dominant cost on M1
# (the Metal baker needs float atomics = M2+).
REAL_PRESETS = {
    "fast": ("512", 1024, 100_000),
    "balanced": ("512", 2048, 200_000),
    "quality": ("1024", 2048, 300_000),
}


def emit(obj):
    print(json.dumps(obj), flush=True)


# --------------------------------------------------------------------------
# Mock mode
# --------------------------------------------------------------------------

def run_mock(args, job_dir, job_id):
    start = time.time()
    scale = SPEED[args.preset]
    total = sum(d for _, d, _ in STAGES) * scale
    done = 0.0

    shutil.copy(args.image, os.path.join(job_dir, "input.png"))
    shutil.copy(args.image, os.path.join(job_dir, "prepared.png"))
    with open(os.path.join(job_dir, "config.json"), "w") as f:
        json.dump({"job_id": job_id, "preset": args.preset, "seed": args.seed,
                   "model_folder": args.model_folder, "mock": True}, f, indent=2)

    for stage, duration, label in STAGES:
        duration *= scale
        emit({"type": "stage_started", "stage": stage, "message": label})
        steps = max(1, int(duration / 0.25))
        for i in range(steps):
            time.sleep(duration / steps)
            percent = int(100 * (done + duration * (i + 1) / steps) / total)
            emit({"type": "progress", "stage": stage, "percent": min(percent, 99), "message": label})
        done += duration

        if stage == "exporting_glb":
            path = os.path.join(job_dir, "output.glb")
            with open(path, "wb") as f:
                f.write(b"3DMate mock placeholder (not a real GLB)")
            emit({"type": "artifact", "kind": "glb", "path": path})
        elif stage == "exporting_usdz":
            path = os.path.join(job_dir, "output.usdz")
            with open(path, "wb") as f:
                f.write(b"3DMate mock placeholder (not a real USDZ)")
            emit({"type": "artifact", "kind": "usdz", "path": path})

    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})


# --------------------------------------------------------------------------
# Real mode — trellis-mac (TRELLIS.2 on PyTorch MPS)
# --------------------------------------------------------------------------

# (regex, stage, percent-at-entry) — first match wins, order matters.
STAGE_PATTERNS = [
    (re.compile(r"loading pipeline|from_pretrained|loading model|loading weights", re.I), "loading_model", 8),
    (re.compile(r"preprocess|background|rembg|segment", re.I), "preparing_image", 16),
    (re.compile(r"sparse structure|stage 1|sampling ss|structure sampl", re.I), "generating_structure", 25),
    (re.compile(r"slat|structured latent|stage 2|decoding|mesh extract|flexicubes|marching", re.I), "generating_mesh", 55),
    (re.compile(r"baking|uv unwrap|xatlas|texture|simplify", re.I), "baking_textures", 75),
    (re.compile(r"saved: .*\.glb|exporting glb", re.I), "exporting_glb", 95),
]

# Paths may contain spaces (e.g. "/Volumes/Sviat SSD/…") — match to end of line.
SAVED_RE = re.compile(r"Saved:\s*(.+?\.(glb|obj|png))\s*$", re.I)


def find_workspace(args):
    ws = os.environ.get("THREEDMATE_WORKSPACE")
    if ws and os.path.isdir(ws):
        return ws
    # output folder is <workspace>/Jobs — derive from there
    parent = os.path.dirname(os.path.abspath(args.output.rstrip("/")))
    return parent if os.path.isdir(parent) else None


def run_real(args, job_dir, job_id):
    start = time.time()
    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})

    workspace = find_workspace(args)
    repo_name = "trellis2-apple" if args.engine == "mlx" else "trellis-mac"

    # Source builds live inside a sparse APFS image on the SSD (exFAT can't
    # host them), mounted at /Volumes/3DMate-Dev — attach it on demand.
    candidates = [
        f"/Volumes/3DMate-Dev/BackendCandidates/{repo_name}",
        os.path.join(workspace or "", "Repos", "BackendCandidates", repo_name),
    ]
    image = os.path.join(workspace or "", "DevRepos.sparseimage")
    if not any(os.path.isdir(c) for c in candidates) and os.path.isfile(image):
        emit({"type": "log", "message": "Attaching workspace dev image…"})
        subprocess.run(["hdiutil", "attach", "-nobrowse", image],
                       capture_output=True, timeout=60)

    repo = next((c for c in candidates if os.path.isdir(c)), candidates[0])
    venv_python = os.path.join(repo, ".venv", "bin", "python3")
    if not os.path.isdir(repo) or not os.path.isfile(venv_python):
        emit({"type": "error", "recoverable": False,
              "message": f"{repo_name} backend not installed in the workspace. Run the Phase 1/2 setup scripts first."})
        sys.exit(4)

    if os.path.abspath(os.path.dirname(args.image)) != os.path.abspath(job_dir):
        shutil.copy(args.image, os.path.join(job_dir, "prepared.png"))
    with open(os.path.join(job_dir, "config.json"), "w") as f:
        json.dump({"job_id": job_id, "preset": args.preset, "seed": args.seed,
                   "model_folder": args.model_folder, "backend": "trellis-mac"}, f, indent=2)

    pipeline_type, texture_size, bake_faces = REAL_PRESETS[args.preset]
    output_base = os.path.join(job_dir, "output")

    env = dict(os.environ)
    env.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
    env["PYTHONUNBUFFERED"] = "1"  # live progress lines, not 8 KB bursts
    env["TRELLIS_BAKE_TARGET_FACES"] = str(bake_faces)
    # Use the pre-downloaded weights in the workspace when they look complete.
    if args.model_folder and os.path.isfile(os.path.join(args.model_folder, "pipeline.json")):
        env["TRELLIS2_MODEL"] = args.model_folder

    if args.engine == "mlx":
        # MLX runner ships next to this wrapper in the app bundle.
        runner = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mlx_runner.py")
        mlx_pipeline = {"512": "512", "1024": "1024_cascade"}[pipeline_type]
        cmd = [venv_python, runner, args.image,
               "--seed", str(args.seed),
               "--output", output_base,
               "--pipeline-type", mlx_pipeline,
               "--texture-size", str(texture_size)]
    else:
        cmd = [venv_python, "generate.py", args.image,
               "--seed", str(args.seed),
               "--output", output_base,
               "--pipeline-type", pipeline_type,
               "--texture-size", str(texture_size)]
    emit({"type": "log", "message": "exec: " + " ".join(cmd)})

    proc = subprocess.Popen(cmd, cwd=repo, env=env, text=True, bufsize=1,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    def forward_terminate(signum, frame):
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
        emit({"type": "job_cancelled"})
        sys.exit(130)

    signal.signal(signal.SIGTERM, forward_terminate)
    signal.signal(signal.SIGINT, forward_terminate)

    stage_order = [s for s, _, _ in STAGES]
    current_stage = "loading_model"
    percent = 5
    artifacts = []

    for line in proc.stdout:
        line = line.rstrip("\n")
        if not line.strip():
            continue
        emit({"type": "log", "message": line})

        for pattern, stage, entry_percent in STAGE_PATTERNS:
            if pattern.search(line):
                # Monotonic: heuristic matches must never move the stage backwards
                # (e.g. torch's "segment_reduce" warnings matching "segment").
                if stage != current_stage and stage_order.index(stage) > stage_order.index(current_stage):
                    current_stage = stage
                    percent = max(percent, entry_percent)
                    label = dict((s, l) for s, _, l in STAGES).get(stage, stage)
                    emit({"type": "stage_started", "stage": stage, "message": label})
                    emit({"type": "progress", "stage": stage, "percent": percent, "message": label})
                break

        saved = SAVED_RE.search(line)
        if saved:
            path = saved.group(1)
            if not os.path.isabs(path):
                path = os.path.join(repo, path)
            if path.endswith(".glb") and os.path.isfile(path):
                dest = os.path.join(job_dir, "output.glb")
                if os.path.abspath(path) != os.path.abspath(dest):
                    shutil.copy(path, dest)
                artifacts.append(dest)
                emit({"type": "artifact", "kind": "glb", "path": dest})

    rc = proc.wait()
    if rc != 0:
        emit({"type": "error", "recoverable": True,
              "message": f"trellis-mac exited with status {rc}. Common causes: Hugging Face login/gated-model access missing (dinov3, RMBG-2.0), or out of memory — try the Fast preset. See logs for the full output."})
        sys.exit(5)

    glb = os.path.join(job_dir, "output.glb")
    if not artifacts and os.path.isfile(output_base + ".glb"):
        if os.path.abspath(output_base + ".glb") != os.path.abspath(glb):
            shutil.copy(output_base + ".glb", glb)
        artifacts.append(glb)
        emit({"type": "artifact", "kind": "glb", "path": glb})
    if not artifacts:
        emit({"type": "error", "recoverable": True,
              "message": "Backend finished but produced no GLB — see logs."})
        sys.exit(6)

    # Use the prepared image as the preview placeholder (real renders later).
    preview = os.path.join(job_dir, "preview.png")
    try:
        shutil.copy(args.image, preview)
        emit({"type": "artifact", "kind": "preview", "path": preview})
    except OSError:
        pass

    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})


def main():
    parser = argparse.ArgumentParser(description="3D Mate generation wrapper")
    parser.add_argument("--image", required=True, help="Input image path")
    parser.add_argument("--model-folder", help="Local TRELLIS.2 model folder (on the external SSD)")
    parser.add_argument("--output", required=True, help="Jobs/ parent folder (on the external SSD)")
    parser.add_argument("--job-id", help="Job folder name; generated when omitted")
    parser.add_argument("--preset", default="balanced", choices=sorted(SPEED))
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--engine", default="mps", choices=["mps", "mlx"],
                        help="Real backend engine: trellis-mac (PyTorch MPS) or trellis2-apple (MLX)")
    parser.add_argument("--mock", action="store_true", help="Simulate the pipeline (no model needed)")
    args = parser.parse_args()

    job_id = args.job_id or "job-" + uuid.uuid4().hex[:8]
    job_dir = os.path.join(args.output, job_id)
    os.makedirs(job_dir, exist_ok=True)

    emit({"type": "job_started", "job_id": job_id})

    if not os.path.isfile(args.image):
        emit({"type": "error", "message": "Input image not found: %s" % args.image, "recoverable": False})
        sys.exit(2)

    if args.mock:
        run_mock(args, job_dir, job_id)
    else:
        run_real(args, job_dir, job_id)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        emit({"type": "job_cancelled"})
        sys.exit(130)
    except BrokenPipeError:
        # Reader went away (e.g. cancelled from the app) — exit quietly.
        sys.exit(0)
