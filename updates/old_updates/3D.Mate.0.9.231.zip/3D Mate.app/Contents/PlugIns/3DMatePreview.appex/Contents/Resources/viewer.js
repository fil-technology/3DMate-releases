// The interactive viewer for the QuickLook HTML preview. Three.js and the
// loaders are inlined ahead of this script; the model bytes and its extension
// are injected as window.__MODEL_B64__ / window.__MODEL_EXT__ by the extension.
(function () {
  "use strict";
  var container = document.getElementById("stage");

  var scene = new THREE.Scene();
  scene.background = new THREE.Color(0x111114);

  var camera = new THREE.PerspectiveCamera(38, window.innerWidth / window.innerHeight, 0.01, 5000);

  var renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
  renderer.setPixelRatio(window.devicePixelRatio || 1);
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputEncoding = THREE.sRGBEncoding;
  container.appendChild(renderer.domElement);

  // Two directional lights plus soft ambient: enough shape without a real IBL,
  // and nothing to fetch from the network (the extension is offline).
  var key = new THREE.DirectionalLight(0xffffff, 2.1); key.position.set(-0.6, 1.0, 0.8); scene.add(key);
  var fill = new THREE.DirectionalLight(0xdfe9ff, 0.9); fill.position.set(0.8, 0.2, -0.4); scene.add(fill);
  scene.add(new THREE.AmbientLight(0xffffff, 0.55));

  var controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.autoRotate = true;
  controls.autoRotateSpeed = 1.1;
  // A drag stops the auto-spin, so a look-around does not fight the animation.
  controls.addEventListener("start", function () { controls.autoRotate = false; });

  function frame(object) {
    var box = new THREE.Box3().setFromObject(object);
    var size = box.getSize(new THREE.Vector3());
    var center = box.getCenter(new THREE.Vector3());
    object.position.sub(center); // re-center at origin

    var radius = Math.max(size.x, size.y, size.z) * 0.5 || 1;
    controls.target.set(0, 0, 0);
    var dist = radius / Math.sin((camera.fov * Math.PI / 180) / 2) * 1.25;
    camera.position.set(radius * 0.5, radius * 0.35, dist);
    camera.near = dist / 100;
    camera.far = dist * 100;
    camera.updateProjectionMatrix();
    controls.update();
    scene.add(object);
  }

  function fail(msg) {
    var el = document.getElementById("msg");
    el.textContent = msg || "This model could not be displayed.";
    el.style.display = "block";
  }

  function base64ToArrayBuffer(b64) {
    var binary = atob(b64);
    var len = binary.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
    return bytes.buffer;
  }

  function normalizeMaterials(root) {
    root.traverse(function (n) {
      if (n.isMesh) {
        n.geometry && n.geometry.computeVertexNormals && !n.geometry.attributes.normal && n.geometry.computeVertexNormals();
        var mats = Array.isArray(n.material) ? n.material : [n.material];
        mats.forEach(function (m) { if (m) { m.side = THREE.DoubleSide; } });
        if (!n.material || (Array.isArray(n.material) && n.material.length === 0)) {
          n.material = new THREE.MeshStandardMaterial({ color: 0xbfc4cc, metalness: 0.1, roughness: 0.7 });
        }
      }
    });
  }

  try {
    var buffer = base64ToArrayBuffer(window.__MODEL_B64__);
    var ext = (window.__MODEL_EXT__ || "").toLowerCase();

    if (ext === "glb" || ext === "gltf") {
      new THREE.GLTFLoader().parse(buffer, "", function (gltf) {
        frame(gltf.scene);
      }, function () { fail(); });
    } else if (ext === "obj") {
      var text = new TextDecoder("utf-8").decode(buffer);
      var obj = new THREE.OBJLoader().parse(text);
      normalizeMaterials(obj); frame(obj);
    } else if (ext === "stl") {
      var geo = new THREE.STLLoader().parse(buffer);
      geo.computeVertexNormals();
      var meshS = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0xbfc4cc, metalness: 0.1, roughness: 0.7 }));
      frame(meshS);
    } else if (ext === "ply") {
      var pgeo = new THREE.PLYLoader().parse(buffer);
      pgeo.computeVertexNormals();
      var hasColor = !!pgeo.attributes.color;
      var meshP = new THREE.Mesh(pgeo, new THREE.MeshStandardMaterial({
        color: hasColor ? 0xffffff : 0xbfc4cc, vertexColors: hasColor, metalness: 0.05, roughness: 0.75
      }));
      frame(meshP);
    } else {
      fail("Unsupported format.");
    }
  } catch (e) {
    fail(String(e));
  }

  function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
  }
  animate();

  window.addEventListener("resize", function () {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
})();
