#!/usr/bin/env python3
"""3D Mate Hi3DGen runner. Emits the same JSONL protocol as the other engines
(job_started / stage_started / progress / artifact / job_finished / error) so the
app consumes it identically.

Hi3DGen (Stable-X / Stable3DGen) produces sharp, normal-bridged GEOMETRY. The
pipeline is: StableNormal turns the photo into a surface-normal map (cutting the
object out with its own BiRefNet), DINOv2 encodes that normal map into
conditioning, and a TRELLIS-v1 sparse flow stack (structure flow + structure
decoder + SLat flow + SLat mesh decoder), ported to Apple MLX, samples the mesh.
Surface extraction is CPU skimage marching cubes. There are no CUDA-only ops.

Two runtimes cooperate in one process, sequentially so only one is Metal-resident
at a time: the StableNormal + DINOv2 front-end is stock PyTorch on MPS, and the
generative core is MLX. The ported core lives in the trellis2-apple `mlx_backend`
package (THREEDMATE_HI3DGEN_REPO); mesh extraction reuses Stable3DGen's
SparseFeatures2Mesh (THREEDMATE_STABLE3DGEN). Weights, the StableNormal hub repo,
and the DINOv2 hub repo are all bundled under --model-folder so the run is
offline."""
import argparse
import json
import os
import sys
import time

os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
# The MLX core attends with torch SDPA and pools sparse voxels natively (no
# spconv/xformers/CUDA); make that explicit for the bundled Stable3DGen import.
os.environ.setdefault("ATTN_BACKEND", "sdpa")
os.environ.setdefault("SPCONV_ALGO", "native")


def emit(obj):
    print(json.dumps(obj), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--image", required=True)
    p.add_argument("--output", default="")
    p.add_argument("--job-id", default="hi3dgen")
    p.add_argument("--model-folder", default="")
    p.add_argument("--seed", default="42")
    p.add_argument("--steps", type=int, default=25, help="flow sampling steps per stage")
    p.add_argument("--normal-resolution", type=int, default=768,
                   help="StableNormal working resolution; higher = finer normals, more memory")
    args, _ = p.parse_known_args()

    start = time.time()
    emit({"type": "job_started", "job_id": args.job_id})

    # The ported MLX core (mlx_backend) and the mesh-extraction reference
    # (Stable3DGen) come from the installed pack, or a dev fork via env.
    repo = os.environ.get("THREEDMATE_HI3DGEN_REPO", "")
    if repo and repo not in sys.path:
        sys.path.insert(0, repo)
    stable3dgen = os.environ.get("THREEDMATE_STABLE3DGEN", "")
    if stable3dgen and stable3dgen not in sys.path:
        sys.path.insert(0, stable3dgen)
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

    emit({"type": "stage_started", "stage": "validating_input", "message": "Validating input"})
    if not os.path.exists(args.image):
        emit({"type": "error", "message": "Input image not found.", "recoverable": False})
        return 1

    # A bundled model folder lays out the weights + hub repos and points the
    # offline caches at itself. On a dev machine everything resolves from the
    # ambient TORCH_HOME / HF_HOME instead.
    mf = args.model_folder
    ckpt_dir = os.environ.get("THREEDMATE_HI3DGEN_CKPTS", "")
    stablenormal_repo = os.environ.get("THREEDMATE_STABLENORMAL_REPO", "") or None
    dinov2_repo = os.environ.get("THREEDMATE_DINOV2_REPO", "") or None
    if mf and os.path.isdir(mf):
        os.environ["TORCH_HOME"] = os.path.join(mf, "torchhub")
        os.environ["HF_HOME"] = os.path.join(mf, "hfcache")
        if not ckpt_dir:
            ckpt_dir = os.path.join(mf, "trellis-normal-v0-1", "ckpts")
        sn = os.path.join(mf, "torchhub", "hub", "hugoycj_StableNormal_main")
        dv = os.path.join(mf, "torchhub", "hub", "facebookresearch_dinov2_main")
        stablenormal_repo = sn if os.path.isdir(sn) else stablenormal_repo
        dinov2_repo = dv if os.path.isdir(dv) else dinov2_repo
    if not ckpt_dir:
        emit({"type": "error", "message": "Hi3DGen weights folder not found.", "recoverable": False})
        return 1

    try:
        import torch  # noqa: F401
        import skimage.measure  # noqa: F401  (pre-load off the hot path)
        from mlx_backend.hi3dgen_pipeline import Hi3DGenPipeline
    except Exception as exc:  # noqa: BLE001
        emit({"type": "error", "message": f"Hi3DGen runtime not available: {exc}", "recoverable": False})
        return 1

    try:
        seed = int(args.seed)
    except (TypeError, ValueError):
        seed = 42

    emit({"type": "stage_started", "stage": "loading_model", "message": "Loading Hi3DGen"})

    _STAGE = {"normal": "generating_structure", "cond": "generating_structure",
              "load": "loading_model", "structure": "generating_structure",
              "latent": "generating_mesh", "mesh": "generating_mesh"}
    _PCT = {"normal": 10, "cond": 20, "structure": 40, "latent": 70, "mesh": 92}

    def progress(stage, message, frac=None):
        wire = _STAGE.get(stage, "generating_structure")
        pct = _PCT.get(stage, 50)
        if frac is not None and stage in ("structure", "latent"):
            base = _PCT.get(stage, 50)
            span = 25 if stage == "structure" else 20
            pct = int(base + span * frac)
        emit({"type": "progress", "stage": wire, "percent": pct, "message": message + "…"})

    job_folder = os.path.dirname(os.path.abspath(args.image))
    try:
        pipe = Hi3DGenPipeline(ckpt_dir, device=("mps" if _mps() else "cpu"),
                               stablenormal_repo=stablenormal_repo, dinov2_repo=dinov2_repo,
                               stable3dgen_path=(stable3dgen or None))
        emit({"type": "stage_started", "stage": "generating_structure", "message": "Estimating normals"})
        mesh = pipe.run(args.image, out_dir=job_folder, steps=args.steps, seed=seed,
                        normal_resolution=args.normal_resolution, progress=progress)
    except Exception as exc:  # noqa: BLE001
        detail = str(exc)
        low_memory = isinstance(exc, MemoryError) or any(
            m in detail for m in ("NoneType", "Interrupted system call", "Cannot allocate", "out of memory"))
        if low_memory:
            emit({"type": "error", "recoverable": True, "message":
                  "Ran low on memory while building the mesh. Close other apps "
                  "(Google Drive especially), then try again, or lower the detail."})
        else:
            emit({"type": "error", "recoverable": False, "message": f"Mesh generation failed: {detail}"})
        return 1

    tm = mesh.to_trimesh(transform_pose=True)
    if tm is None or len(tm.vertices) == 0:
        emit({"type": "error", "recoverable": True, "message":
              "The mesh step produced no geometry, usually a sign the machine ran low on memory."})
        return 1

    try:
        if tm.volume < 0:
            tm.invert()
    except Exception:  # noqa: BLE001
        pass

    emit({"type": "stage_started", "stage": "generating_mesh", "message": "Building mesh"})
    out_glb = os.path.join(job_folder, "output.glb")
    tm.export(out_glb)
    emit({"type": "artifact", "kind": "glb", "path": out_glb})

    out_stl = os.path.join(job_folder, "output.stl")
    try:
        tm.export(out_stl)
        emit({"type": "artifact", "kind": "stl", "path": out_stl})
    except Exception as exc:  # noqa: BLE001
        emit({"type": "log", "level": "warning", "message": f"STL export failed: {exc}"})

    emit({"type": "stage_started", "stage": "exporting_glb", "message": "Finishing"})
    emit({"type": "job_finished", "duration_seconds": round(time.time() - start, 1)})
    return 0


def _mps():
    try:
        import torch
        return torch.backends.mps.is_available()
    except Exception:  # noqa: BLE001
        return False


if __name__ == "__main__":
    sys.exit(main())
