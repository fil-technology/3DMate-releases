#!/usr/bin/env python3
"""Headless MLX generation for 3D Mate.

Runs inside the trellis2-apple checkout with its .venv (cwd must be the repo).
Progress lines are formatted to match the stage regexes in
trellismac_generate.py. On M1 (no float atomics) the Metal postprocess path
fails — we fall back to the KDTree baker shared with the trellis-mac checkout.
"""
import argparse
import os
import sys
import time


def log(message):
    print(message, flush=True)


def to_numpy(value, dtype=None):
    import numpy as np
    if hasattr(value, "cpu"):  # torch tensor
        value = value.cpu().float().numpy()
    array = np.asarray(value)
    return array.astype(dtype) if dtype is not None else array


def kdtree_bake(mesh, output_base, texture_size):
    """Port of trellis-mac's fallback bake (simplify → xatlas → KDTree)."""
    import numpy as np
    sibling = os.path.abspath(os.path.join(os.getcwd(), "..", "trellis-mac"))
    sys.path.insert(0, sibling)
    from backends.texture_baker import uv_unwrap, bake_texture, export_glb_with_texture
    import fast_simplification

    verts = to_numpy(mesh.vertices, np.float32)
    faces = to_numpy(mesh.faces)
    voxel_coords = to_numpy(mesh.coords, np.float32)
    voxel_attrs = to_numpy(mesh.attrs, np.float32)
    origin = to_numpy(mesh.origin, np.float32) if hasattr(mesh, "origin") else np.array([-0.5, -0.5, -0.5], np.float32)
    voxel_size = float(mesh.voxel_size)

    target = int(os.environ.get("TRELLIS_BAKE_TARGET_FACES", "100000"))
    if len(faces) > target:
        log(f"  Simplifying mesh: {len(faces):,} -> ~{target:,} faces")
        verts, faces = fast_simplification.simplify(verts, faces, 1.0 - target / len(faces))
    log("  UV unwrapping with xatlas...")
    new_verts, new_faces, uvs, _ = uv_unwrap(verts, faces)
    log(f"Baking PBR textures via KDTree ({texture_size}x{texture_size})...")
    base_color, mr, _ = bake_texture(new_verts, new_faces, uvs,
                                     voxel_coords, voxel_attrs, origin, voxel_size,
                                     texture_size=texture_size)
    glb_path = output_base + ".glb"
    export_glb_with_texture(new_verts, new_faces, uvs, base_color, mr, glb_path)
    log(f"Saved: {glb_path}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("image")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", default="output_3d")
    parser.add_argument("--pipeline-type", default="512", choices=["512", "1024_cascade", "1536_cascade"])
    parser.add_argument("--texture-size", type=int, default=1024)
    args = parser.parse_args()

    sys.path.insert(0, os.getcwd())
    from PIL import Image
    import o_voxel

    log("Loading pipeline (MLX)...")
    from mlx_backend.pipeline import create_mlx_pipeline
    weights = os.environ.get("TRELLIS2_MODEL", "microsoft/TRELLIS.2-4B")
    pipeline = create_mlx_pipeline(weights_path=weights)

    log("Preprocessing image")
    image = pipeline.preprocess_image(Image.open(args.image))

    log("Sampling sparse structure (MLX)")
    t0 = time.time()
    meshes = pipeline.run(
        image,
        seed=args.seed,
        sparse_structure_sampler_params={"steps": 12, "guidance_strength": 7.5},
        shape_slat_sampler_params={"steps": 12, "guidance_strength": 7.5},
        tex_slat_sampler_params={"steps": 12, "guidance_strength": 1.0},
        pipeline_type=args.pipeline_type,
    )
    mesh = meshes[0]
    log(f"Mesh extraction done: {to_numpy(mesh.faces).shape[0]:,} raw faces in {time.time() - t0:.1f}s")

    target = int(os.environ.get("TRELLIS_BAKE_TARGET_FACES", "100000"))
    output_base = args.output
    try:
        log("Baking PBR textures via Metal...")
        glb = o_voxel.postprocess.to_glb(
            vertices=mesh.vertices,
            faces=mesh.faces,
            attr_volume=mesh.attrs,
            coords=mesh.coords,
            attr_layout=mesh.layout,
            voxel_size=mesh.voxel_size,
            aabb=[[-0.5, -0.5, -0.5], [0.5, 0.5, 0.5]],
            decimation_target=target,
            texture_size=args.texture_size,
            verbose=True,
        )
        glb_path = output_base + ".glb"
        glb.export(glb_path)
        log(f"Saved: {glb_path}")
    except RuntimeError as error:
        log(f"Metal bake failed: {error}")
        log("Falling back to KDTree texture baker...")
        kdtree_bake(mesh, output_base, args.texture_size)

    log(f"Total time: {time.time() - t0:.1f}s generation + baking")


if __name__ == "__main__":
    main()
